﻿#include "MyPlayer.h"
#include "GameFramework/PlayerController.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/InputComponent.h"
#include "Kismet/KismetMathLibrary.h"
#include "Engine/World.h"
#include "Kismet/GameplayStatics.h"
#include "EngineUtils.h"
#include "DialogueWidget.h"
#include "NPC.h"
#include "QuickInventorySlot.h"

// -------------------------------
// Constructor
// -------------------------------
AMyPlayer::AMyPlayer()
{
    PrimaryActorTick.bCanEverTick = true;

    // --- Camera ---
    SpringArm = CreateDefaultSubobject<USpringArmComponent>(TEXT("SpringArm"));
    SpringArm->SetupAttachment(RootComponent);
    SpringArm->TargetArmLength = 300.f;
    SpringArm->bUsePawnControlRotation = true;
    SpringArm->bEnableCameraLag = true;
    SpringArm->CameraLagSpeed = 10.f;

    Camera = CreateDefaultSubobject<UCameraComponent>(TEXT("Camera"));
    Camera->SetupAttachment(SpringArm, USpringArmComponent::SocketName);
    Camera->bUsePawnControlRotation = false;

    FirstPersonCamera = CreateDefaultSubobject<UCameraComponent>(TEXT("FirstPersonCamera"));
    FirstPersonCamera->SetupAttachment(RootComponent);
    FirstPersonCamera->bUsePawnControlRotation = true;
    FirstPersonCamera->SetActive(false); // 기본은 비활성화

    bIsFirstPerson = false;

    // --- Movement ---
    GetCharacterMovement()->MaxWalkSpeed = WalkSpeed;
    GetCharacterMovement()->bOrientRotationToMovement = true;
    bUseControllerRotationYaw = false;

    // --- Katana Effects ---
    WindAura = CreateDefaultSubobject<UNiagaraComponent>(TEXT("WindAura"));
    WindAura->SetupAttachment(RootComponent);
    WindAura->bAutoActivate = false;

    LightningAura = CreateDefaultSubobject<UNiagaraComponent>(TEXT("LightningAura"));
    LightningAura->SetupAttachment(RootComponent);
    LightningAura->bAutoActivate = false;

    FireAura = CreateDefaultSubobject<UNiagaraComponent>(TEXT("FireAura"));
    FireAura->SetupAttachment(RootComponent);
    FireAura->bAutoActivate = false;

    // --- Audio ---
    BGM_Audio = CreateDefaultSubobject<UAudioComponent>(TEXT("BGM_Audio"));
    BGM_Audio->bAutoActivate = false; 
    BGM_Audio->SetupAttachment(RootComponent);
}

void AMyPlayer::SwitchToFirstPerson(AActor* TargetActor /*= nullptr*/)
{
    // 카메라 전환
    FirstPersonCamera->SetActive(true);
    Camera->SetActive(false);
    bIsFirstPerson = true;

    FirstPersonCamera->bUsePawnControlRotation = true;
    Camera->bUsePawnControlRotation = false;

    // 대상이 있으면 플레이어와 카메라가 바라보도록
    if (TargetActor)
    {
        // 1️⃣ 플레이어 회전 (수평만)
        FVector ToTarget = TargetActor->GetActorLocation() - GetActorLocation();
        ToTarget.Z = 0;
        SetActorRotation(ToTarget.Rotation());

        // 2️⃣ 카메라 회전 (정확히 대상 바라봄)
        if (APlayerController* PC = Cast<APlayerController>(GetController()))
        {
            FVector CameraLocation = FirstPersonCamera->GetComponentLocation();
            FVector TargetLocation = TargetActor->GetActorLocation();

            // 1️⃣ 카메라와 대상 눈높이 맞추기
            TargetLocation.Z += 50.f; // 50.f 만큼 위로 올려서 눈/머리 높이 바라보기 (조정 가능)

            FVector LookDir = TargetLocation - CameraLocation;
            FRotator TargetRot = LookDir.Rotation();

            // 2️⃣ Pitch 제한 (원하면 조정 가능)
            TargetRot.Pitch = FMath::Clamp(TargetRot.Pitch, -10.f, 30.f);

            PC->SetControlRotation(TargetRot);
        }
    }
}

void AMyPlayer::SwitchToThirdPerson()
{
    FirstPersonCamera->SetActive(false);
    Camera->SetActive(true);
    bIsFirstPerson = false;

    FirstPersonCamera->bUsePawnControlRotation = false;
    Camera->bUsePawnControlRotation = false;

    SpringArm->TargetArmLength = 300.f;
    SpringArm->SetWorldRotation(GetActorRotation());

    if (APlayerController* PC = Cast<APlayerController>(GetController()))
    {
        PC->SetViewTargetWithBlend(this, 0.5f, VTBlend_Cubic);
    }
}

// -------------------------------
// BeginPlay
// -------------------------------
void AMyPlayer::BeginPlay()
{
    Super::BeginPlay();

    SpawnWeapon();
    InitializePlantSpots();
    HeaterWidgetInstance->SetVisibility(ESlateVisibility::Hidden);
    DialogueWidgetInstance->SetVisibility(ESlateVisibility::Hidden);
    // Purification Widget 생성
    if (PurificationWidgetClass)
    {
        APlayerController* PC = Cast<APlayerController>(GetController());
        PurificationInstance = CreateWidget<UPurificationPercentageWidget>(PC, PurificationWidgetClass);
        PurificationInstance->SetVisibility(ESlateVisibility::Hidden);
    }
}

// ----------------------------
// 무기 스폰
// ----------------------------
void AMyPlayer::SpawnWeapon()
{
    if (!KatanaBPClass) return;

    FActorSpawnParameters SpawnParams;
    SpawnParams.Owner = this;

    Weapon = GetWorld()->SpawnActor<AKatanaBase>(KatanaBPClass, SpawnParams);
    if (Weapon)
    {
        Weapon->AttachToComponent(
            GetMesh(),
            FAttachmentTransformRules::SnapToTargetNotIncludingScale,
            FName("KatanaBackSocket"));
    }

    if (!WeaponSheathBPClass) return;

    WeaponSheath = GetWorld()->SpawnActor<AActor>(WeaponSheathBPClass);
    if (WeaponSheath)
    {
        WeaponSheath->AttachToComponent(
            GetMesh(),
            FAttachmentTransformRules::SnapToTargetNotIncludingScale,
            FName("KatanaBackSocket"));
    }
}

// ----------------------------
// 스팟 초기화
// ----------------------------
void AMyPlayer::InitializePlantSpots()
{
    // Elementals
    Elementals.Empty();
    for (TActorIterator<AElemental> It(GetWorld()); It; ++It)
    {
        Elementals.Add(*It);
    }

    // PlantSpots
    PlantSpots.Empty();
    for (TActorIterator<APlantingTrees> It(GetWorld()); It; ++It)
    {
        PlantSpots.Add(*It);
    }

    // HeatSpots
    HeatSpots.Empty();
    for (TActorIterator<AHeatingZone> It(GetWorld()); It; ++It)
    {
        HeatSpots.Add(*It);
    }

    // TargetBrickSpot
    TargetBrickSpot = nullptr;
    for (TActorIterator<ABrickHoldZone> It(GetWorld()); It; ++It)
    {
        TargetBrickSpot = *It;
        break;
    }

    // TargetTower
    TargetTower = nullptr;
    for (TActorIterator<ATower> It(GetWorld()); It; ++It)
    {
        TargetTower = *It;
        break;
    }

    // TargetNet
    TargetNet = nullptr;
    for (TActorIterator<ANet> It(GetWorld()); It; ++It)
    {
        TargetNet = *It;
        break;
    }
}

// -------------------------------
// Tick
// -------------------------------
void AMyPlayer::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

    UpdateMovementSpeed(DeltaTime);
    UpdateWeaponBlend(DeltaTime);
    UpdateStamina(DeltaTime);
    // --- Lock-On rotation update ---
    UpdateLockOnRotation(DeltaTime);
}

void AMyPlayer::UpdateMovementSpeed(float DeltaTime)
{
    float TargetSpeed = bIsRunning ? RunSpeed : WalkSpeed;
    float CurrentSpeed = GetCharacterMovement()->MaxWalkSpeed;
    GetCharacterMovement()->MaxWalkSpeed =
        FMath::FInterpTo(CurrentSpeed, TargetSpeed, DeltaTime, 5.f);
    CurrentSpeedValue = GetVelocity().Size2D();
}

void AMyPlayer::UpdateWeaponBlend(float DeltaTime)
{
    float TargetWeaponBlend = bIsWeaponEquipped ? 100.f : 0.f;
    WeaponBlendValue = FMath::FInterpTo(WeaponBlendValue, TargetWeaponBlend, DeltaTime, 1.5f);
}

void AMyPlayer::UpdateStamina(float DeltaTime)
{
    // 기본 회복/소모 값
    float StaminaChange = 0.f;

    bool bOnGround = GetCharacterMovement()->IsMovingOnGround();
    bool bHasMovementInput = FMath::Abs(ForwardAxisValue) > 0.1f || FMath::Abs(RightAxisValue) > 0.1f;

    if (!bIsExhausted && !bIsAttacking)
    {
        if (bOnGround)
        {
            if (bIsParrying)
                StaminaChange = -20.f;           // 패링 중
            else if (bIsRunning && bHasMovementInput)
                StaminaChange = -15.f;           // 달리기 중
            else
                StaminaChange = StaminaRecoveryRate; // 땅 위 정지 중 회복
        }
        else
        {
            StaminaChange = StaminaRecoveryRate;     // 공중 회복
        }
    }
    else
    {
        StaminaChange = StaminaRecoveryRate;         // 탈진/공격 중 회복
    }

    // 프레임 독립적 계산
    Stamina += StaminaChange * DeltaTime;

    // Clamp & 탈진 체크
    Stamina = FMath::Clamp(Stamina, 0.f, MaxStamina);
    bIsExhausted = (Stamina <= 0.f);

    // 상태에 따른 자동 처리
    if (bIsParrying && bIsExhausted)
        ParryActionReleased();

    if (bIsRunning && bIsExhausted)
        bIsRunning = false;
}


// -------------------------------
// PostInitializeComponents
// -------------------------------
void AMyPlayer::PostInitializeComponents()
{
    Super::PostInitializeComponents();
    AnimInstance = Cast<UMyPlayerAnim>(GetMesh()->GetAnimInstance());
}

// -------------------------------
// Input Setup
// -------------------------------
void AMyPlayer::SetupPlayerInputComponent(UInputComponent* PlayerInputComponent)
{
    Super::SetupPlayerInputComponent(PlayerInputComponent);

    // Movement
    PlayerInputComponent->BindAxis("MoveForward", this, &AMyPlayer::MoveForward);
    PlayerInputComponent->BindAxis("MoveRight", this, &AMyPlayer::MoveRight);
    PlayerInputComponent->BindAxis("Turn", this, &AMyPlayer::Turn);
    PlayerInputComponent->BindAxis("LookUp", this, &AMyPlayer::LookUp);

    PlayerInputComponent->BindAction("MouseWheelUp", IE_Pressed, this, &AMyPlayer::OnMouseWheelUp);
    PlayerInputComponent->BindAction("MouseWheelDown", IE_Pressed, this, &AMyPlayer::OnMouseWheelDown);

    // Actions
    PlayerInputComponent->BindAction("Jump", IE_Pressed, this, &AMyPlayer::JumpAction);
    PlayerInputComponent->BindAction("Run", IE_Pressed, this, &AMyPlayer::StartRun);
    PlayerInputComponent->BindAction("Run", IE_Released, this, &AMyPlayer::StopRun);
    PlayerInputComponent->BindAction("Attack", IE_Pressed, this, &AMyPlayer::AttackAction);
    PlayerInputComponent->BindAction("ToggleWeapon", IE_Pressed, this, &AMyPlayer::ToggleWeapon);
    PlayerInputComponent->BindAction("Rolling", IE_Pressed, this, &AMyPlayer::Rolling);

    // Effects
    PlayerInputComponent->BindAction("ActivateEffect1", IE_Pressed, this, &AMyPlayer::WindEffect1);
    PlayerInputComponent->BindAction("ActivateEffect2", IE_Pressed, this, &AMyPlayer::LightningEffect2);
    PlayerInputComponent->BindAction("ActivateEffect3", IE_Pressed, this, &AMyPlayer::FireEffect3);

    // Defense / Lock-On
    PlayerInputComponent->BindAction("Defense", IE_Pressed, this, &AMyPlayer::ParryActionPressed);
    PlayerInputComponent->BindAction("Defense", IE_Released, this, &AMyPlayer::ParryActionReleased);
    PlayerInputComponent->BindAction("LockOn", IE_Pressed, this, &AMyPlayer::ToggleLockOn);

    PlayerInputComponent->BindAction("Quest", IE_Pressed, this, &AMyPlayer::Quest);
    PlayerInputComponent->BindAction("Interact", IE_Pressed, this, &AMyPlayer::Interact);
    PlayerInputComponent->BindAction("UseItem", IE_Pressed, this, &AMyPlayer::UseItem);

    // World Map
    PlayerInputComponent->BindAction("OpenMap", IE_Pressed, this, &AMyPlayer::ToggleMap);
}

void AMyPlayer::OnMouseWheelUp()
{
    if (QuickInventoryInstance)
    {
        QuickInventoryInstance->ChangeSlotIndex(+1.0f);
    }
}

void AMyPlayer::OnMouseWheelDown()
{
    if (QuickInventoryInstance)
    {
        QuickInventoryInstance->ChangeSlotIndex(-1.0f);
    }
}

void AMyPlayer::ModifyHealth(float Amount)
{
    HP += Amount;
    HP = FMath::Clamp(HP, 0.f, MaxHP);
}

void AMyPlayer::ModifyStamina(float Amount)
{
    Stamina += Amount;
    Stamina = FMath::Clamp(Stamina, 0.f, MaxStamina);
}

// -------------------------------
// Movement
// -------------------------------
void AMyPlayer::MoveForward(float Value)
{
    if (bIsAttacking || bIsParrying || bIsDead || OnQuest) return;
    ForwardAxisValue = Value;

    if (Controller && Value != 0.f)
    {
        FRotator MoveRot = bIsLockedOn ? GetActorRotation() : FRotator(0.f, Controller->GetControlRotation().Yaw, 0.f);
        AddMovementInput(MoveRot.Vector(), Value);
    }
}

void AMyPlayer::MoveRight(float Value)
{
    if (bIsAttacking || bIsParrying || bIsDead || OnQuest) return;
    RightAxisValue = Value;

    if (Controller && Value != 0.f)
    {
        FRotator MoveRot = bIsLockedOn ? GetActorRotation() : FRotator(0.f, Controller->GetControlRotation().Yaw, 0.f);
        AddMovementInput(FRotationMatrix(MoveRot).GetUnitAxis(EAxis::Y), Value);
    }
}

void AMyPlayer::Turn(float Value) 
{
    if (OnHeaterQuest) return;
    AddControllerYawInput(Value * LookSensitivity); 
}
void AMyPlayer::LookUp(float Value)
{ 
    if (OnHeaterQuest) return;
    AddControllerPitchInput(Value * LookSensitivity); 
}

void AMyPlayer::JumpAction()
{
    if (bIsRolling || bIsAttacking || bIsParrying || bIsDead || OnQuest) return;

    // 점프 실행
    Jump();
}

void AMyPlayer::StartRun()
{
    if (bIsExhausted || bIsLockedOn || OnQuest) return;
    bIsRunning = true;
}

void AMyPlayer::StopRun() { bIsRunning = false; }

// -------------------------------
// Rolling
// -------------------------------
void AMyPlayer::Rolling()
{
    if (bIsRolling || !RollMontage || !AnimInstance || bIsDead || OnQuest) return;
    if (Stamina < 20.f) return; // 스태미나 부족 시 구르기 불가

    FVector InputVector = FVector(ForwardAxisValue, RightAxisValue, 0.f);

    if (bIsLockedOn) // 락온 상태 구르기
    {
        FString RollDirection = "ForwardRoll"; // 기본값

        // 입력 방향에 따른 섹션 선택
        if (ForwardAxisValue > 0.5f)
            RollDirection = "ForwardRoll";
        else if (ForwardAxisValue < -0.5f)
            RollDirection = "BackwardRoll";
        else if (RightAxisValue > 0.5f)
            RollDirection = "RightRoll";
        else if (RightAxisValue < -0.5f)
            RollDirection = "LeftRoll";
        PlayRollMontage(RollDirection);
    }
    else // 일반 구르기 (현재처럼 입력 벡터 방향)
    {
        if (!InputVector.IsNearlyZero())
        {
            InputVector.Normalize();

            // 카메라 기준 방향 적용
            if (Controller)
            {
                FRotator ControlRot = Controller->GetControlRotation();
                FRotator YawRot(0, ControlRot.Yaw, 0);
                FVector RollDir = FRotationMatrix(YawRot).TransformVector(InputVector);

                SetActorRotation(RollDir.Rotation());
            }
        }
        PlayRollMontage("");
    }
}

void AMyPlayer::PlayRollMontage(const FString& SectionName)
{
    if (!AnimInstance || !RollMontage || bIsDead) return;

    // 스태미나 차감 (안전하게 처리)
    Stamina = FMath::Max(0.f, Stamina - 20.f);

    // 상태 설정
    bIsRolling = true;
    bIsInvincible = true;

    // 몽타주 재생
    AnimInstance->Montage_Play(RollMontage, 1.f);

    // 섹션이 주어졌으면 해당 섹션으로 이동 (락온 구르기 등)
    if (!SectionName.IsEmpty())
    {
        AnimInstance->Montage_JumpToSection(FName(*SectionName), RollMontage);
    }

    // 주의: Montage_SetEndDelegate는 해당 몽타주에 대해 덮어씀. (중복 바인딩 주의)
    FOnMontageEnded EndDelegate;
    EndDelegate.BindLambda([this](UAnimMontage* Montage, bool bInterrupted)
        {
            // 몽타주가 끝나면 상태 해제
            bIsRolling = false;
            bIsInvincible = false;
        });
    AnimInstance->Montage_SetEndDelegate(EndDelegate, RollMontage);
}

void AMyPlayer::UseItem()
{
    if (QuickInventoryInstance)
    {
        QuickInventoryInstance->UseSelectedItem(this);
        QuickInventoryInstance->UpdateSlotImage();
    }
}

void AMyPlayer::PlantTree()
{
    if (bIsWeaponEquipped || OnQuest)
        return;

    const float InteractionRange = 150.f;
    float ClosestDistance = InteractionRange;
    APlantingTrees* ClosestSpot = nullptr;

    const FVector PlayerLocation = GetActorLocation();

    // 가장 가까운 나무심기 위치 탐색
    for (APlantingTrees* Spot : PlantSpots)
    {
        if (!Spot || Spot->bIsPlanted)
            continue;

        const float Dist = FVector::Dist(PlayerLocation, Spot->GetActorLocation());
        if (Dist < ClosestDistance)
        {
            ClosestDistance = Dist;
            ClosestSpot = Spot;
        }
    }

    // 찾은 스팟이 없으면 종료
    if (!ClosestSpot || !AnimInstance || !QuestMontage || !TreeSeeds)
        return;

    TargetPlantSpot = ClosestSpot;
    OnQuest = true;

    AnimInstance->Montage_Play(QuestMontage, 1.f);
    AnimInstance->Montage_JumpToSection(PlantSection);
}

void AMyPlayer::TowerReconstruction()
{
    const float InteractionRange = 150.f;
    float ClosestDistance = InteractionRange;
    AActor* ClosestTarget = nullptr;

    FVector PlayerLocation = GetActorLocation();

    if (TargetTower && BrickCount > 0)
    {
        float Dist = FVector::Dist(PlayerLocation, TargetTower->GetActorLocation());
        if (Dist < 1000.f)
        {
            ClosestTarget = TargetTower;
            if (ATower* Tower = Cast<ATower>(ClosestTarget))
            {
                OnQuest = true;
                AnimInstance->Montage_Play(QuestMontage, 1.f);
                AnimInstance->Montage_JumpToSection(TowerSection);
            }
        }
    }
}

void AMyPlayer::Quest()
{
    if (bIsWeaponEquipped || OnQuest)
        return;

    const float InteractionRange = 150.f;
    float ClosestDistance = InteractionRange;
    AActor* ClosestTarget = nullptr;
    enum class EQuestType { None, Heat, Brick, Net } QuestType = EQuestType::None;

    FVector PlayerLocation = GetActorLocation();

    // ----------------------------
    // 난방존 찾기
    // ----------------------------
    for (AHeatingZone* Spot : HeatSpots)
    {
        if (!Spot) continue;
        float Dist = FVector::Dist(PlayerLocation, Spot->GetActorLocation());
        if (Dist < ClosestDistance)
        {
            ClosestDistance = Dist;
            ClosestTarget = Spot;
            QuestType = EQuestType::Heat;
        }
    }

    // ----------------------------
    // 벽돌 획득
    // ----------------------------
    if (TargetBrickSpot)
    {
        float Dist = FVector::Dist(PlayerLocation, TargetBrickSpot->GetActorLocation());
        if (Dist < ClosestDistance+350.f)
        {
            ClosestDistance = Dist;
            ClosestTarget = TargetBrickSpot;
            QuestType = EQuestType::Brick;
        }
    }

    // ----------------------------
    // 그물
    // ----------------------------
    if (TargetNet)
    {
        float Dist = FVector::Dist(PlayerLocation, TargetNet->GetActorLocation());
        if (Dist < ClosestDistance+350.f)
        {
            ClosestDistance = Dist;
            ClosestTarget = TargetNet;
            QuestType = EQuestType::Net;
        }
    }

    // ----------------------------
    // 행동 수행
    // ----------------------------
    switch (QuestType)
    {
    case EQuestType::Net:
        if (ANet* Net = Cast<ANet>(ClosestTarget))
        {
            if (Net->ActiveNet) return;
            OnQuest = true;

            AnimInstance->Montage_Play(QuestMontage, 1.f);
            AnimInstance->Montage_JumpToSection(NetSection); 
        }
        break;

    case  EQuestType::Brick:
        if (BrickCount == 0)
        {
            OnQuest = true;

            AnimInstance->Montage_Play(QuestMontage, 1.f);
            AnimInstance->Montage_JumpToSection(BrickSection);
        }
        break;

    case EQuestType::Heat:
        if (APlayerController* PC = Cast<APlayerController>(GetController()))
        {
            HeaterWidgetInstance->SetVisibility(ESlateVisibility::Visible);
            PC->bShowMouseCursor = true;
            HeaterController = true;
            OnQuest = true;
            OnHeaterQuest = true;
        }
        break;

    default:
        break;
    }
}

void AMyPlayer::ElementalSummoning(float ForwardOffset)
{
    if (Elementals.Num() == 0) return;

    OnQuest = true;
    OnHeaterQuest = true;

    // 플레이어 위치와 회전
    FVector PlayerLocation = GetActorLocation();
    FRotator PlayerRotation = GetActorRotation();

    // 가장 가까운 원소 찾기
    ClosestElemental = nullptr;
    float ClosestDistance = FLT_MAX;

    for (AElemental* Elem : Elementals)
    {
        if (!Elem) continue;

        float Dist = FVector::Dist(PlayerLocation, Elem->GetActorLocation());
        if (Dist < ClosestDistance)
        {
            ClosestDistance = Dist;
            ClosestElemental = Elem;
        }
    }

    if (!ClosestElemental) return;

    // 정령을 플레이어 앞에 배치
    FVector ForwardVector = PlayerRotation.Vector();
    float ElementHeightOffset = 30.f; // 예: 플레이어보다 50 유닛 위
    FVector ElementLocation = PlayerLocation + ForwardVector;
    ElementLocation.Z += ElementHeightOffset; // 높이 추가
    ClosestElemental->SetActorLocation(ElementLocation);

    // 플레이어를 정령 뒤로 배치
    FVector BackwardDir = -ForwardVector; // 정령 뒤쪽
    FVector NewPlayerLocation = ElementLocation + BackwardDir * ForwardOffset;
    SetActorLocation(NewPlayerLocation);

    // 5️⃣ 정령이 플레이어를 바라보도록 회전 (메시 기준 보정 포함)
    FVector ElementLookDir = GetActorLocation() - ElementLocation; // 플레이어 위치 기준
    FRotator ElementRotation = ElementLookDir.Rotation();
    ElementRotation.Yaw -= 90.f; // 메시 기본 방향 보정
    ClosestElemental->SetActorRotation(ElementRotation);

    // 대화 UI 표시
    if (DialogueWidgetInstance)
    {
        DialogueWidgetInstance->ShowElementalDialogue(ClosestElemental->ElementName.ToString());
    }

    if (!bIsFirstPerson)
        SwitchToFirstPerson(ClosestElemental);

    ClosestElemental->PlaySummonMontage();

    if (APlayerController* PC = Cast<APlayerController>(GetController()))
        PC->bShowMouseCursor = true;
}

// 상호작용
void AMyPlayer::Interact()
{
    FVector Start = GetActorLocation() + FVector(0, 0, 70.f);
    FVector Forward = GetControlRotation().Vector();
    FVector End = Start + Forward * 300.f;

    FHitResult Hit;
    FCollisionQueryParams Params;
    Params.AddIgnoredActor(this);

    bool bHit = GetWorld()->LineTraceSingleByChannel(Hit, Start, End, ECC_Visibility, Params);

    if (bHit)
    {
        ANPC* NPC = Cast<ANPC>(Hit.GetActor());
        if (NPC)
        {
            const float InteractionDist = 200.f;
            float Distance = FVector::Dist(GetActorLocation(), NPC->GetActorLocation());

            if (Distance < InteractionDist)
            {
                if (DialogueWidgetInstance)
                {
                    if (APlayerController* PC = Cast<APlayerController>(GetController()))
                    {
                        // 플레이어가 NPC를 바라보게 함
                        FVector ToNPC = NPC->GetActorLocation() - GetActorLocation();
                        ToNPC.Z = 0;
                        FRotator PlayerRot = ToNPC.Rotation();
                        SetActorRotation(PlayerRot);

                        // 일인칭 모드 전환
                        if (!bIsFirstPerson)
                            SwitchToFirstPerson(NPC);

                        // NPC와 거리 유지 (300.f)
                        FVector DirToNPC = (GetActorLocation() - NPC->GetActorLocation()).GetSafeNormal();
                        FVector DesiredPlayerLoc = NPC->GetActorLocation() + DirToNPC * 250.f;
                        SetActorLocation(DesiredPlayerLoc);

                        // NPC도 플레이어 쪽으로 회전
                        FVector ToPlayer = GetActorLocation() - NPC->GetActorLocation();
                        ToPlayer.Z = 0;
                        NPC->SetActorRotation(ToPlayer.Rotation());

                        PC->bShowMouseCursor = true;
                        OnHeaterQuest = true;
                        OnQuest = true;
                    }

                    DialogueWidgetInstance->SetVisibility(ESlateVisibility::Visible);
                    DialogueWidgetInstance->ShowElementalDialogue(NPC->NPCName.ToString());
                }
            }
        }
    }
}

// -------------------------------
// Attack / Combo
// -------------------------------
void AMyPlayer::AttackAction()
{
    if (!bIsWeaponEquipped || !AnimInstance || !AttackMontage || bIsRolling || bIsDead || OnQuest) return;

    if (!bIsAttacking)
    {
        CurrentCombo = 0;
        bIsAttacking = true;
        bCanNextCombo = false;
        PlayAttackMontage();
    }
    else if (bCanNextCombo)
    {
        bCanNextCombo = false;
        CurrentCombo = (CurrentCombo + 1) % MaxCombo;
        JumpToNextAttackSection();
    }
}

void AMyPlayer::PlayAttackMontage()
{
    if (!AnimInstance || !AttackMontage) return;

    AnimInstance->Montage_Play(AttackMontage, Weapon->AttackSpeed);
    FString sectionName = FString::Printf(TEXT("Attack%d"), CurrentCombo);
    AnimInstance->Montage_JumpToSection(FName(*sectionName), AttackMontage);

    FOnMontageEnded EndDelegate;
    EndDelegate.BindUObject(this, &AMyPlayer::OnAttackMontageEnded);
    AnimInstance->Montage_SetEndDelegate(EndDelegate, AttackMontage);
}

void AMyPlayer::JumpToNextAttackSection()
{
    if (!AnimInstance || !AttackMontage) return;
    FString sectionName = FString::Printf(TEXT("Attack%d"), CurrentCombo);
    AnimInstance->Montage_JumpToSection(FName(*sectionName), AttackMontage);
}

void AMyPlayer::OnAttackMontageEnded(UAnimMontage* Montage, bool bInterrupted)
{
    if (Montage == AttackMontage)
    {
        bIsAttacking = false;
        CurrentCombo = 0;
    }
}

// -------------------------------
// Weapon / Effects
// -------------------------------
void AMyPlayer::ToggleWeapon()
{
    if (!Weapon || bIsRolling || bIsDead || OnQuest) return;

    if (bIsWeaponEquipped)
    {
        if (SheatheWeaponMontage) PlayAnimMontage(SheatheWeaponMontage);
        if (bIsLockedOn) StopLockOn();
        Weapon->StopAllEffects();
    }
    else
    {
        if (DrawWeaponMontage) PlayAnimMontage(DrawWeaponMontage);
    }

    bIsWeaponEquipped = !bIsWeaponEquipped;
}

void AMyPlayer::EquipWeapon()
{
    if (!Weapon) return;
    Weapon->AttachToComponent(GetMesh(),
        FAttachmentTransformRules::SnapToTargetNotIncludingScale,
        FName("KatanaHandSocket"));
    bIsWeaponEquipped = true;
}

void AMyPlayer::UnequipWeapon()
{
    if (!Weapon) return;
    Weapon->AttachToComponent(GetMesh(),
        FAttachmentTransformRules::SnapToTargetNotIncludingScale,
        FName("KatanaBackSocket"));
    bIsWeaponEquipped = false;
}

void AMyPlayer::WindEffect1()
{
    for (AElemental* Elem : Elementals)
    {
        if (Elem && Elem->bWindSkillUnlocked && bIsWeaponEquipped)
        {
            if (Weapon->ActivateEffect(1))
            {
                WindAura->Activate(true);
            }
            break; // 하나만 적용하고 싶으면 break
        }
    }
}

void AMyPlayer::LightningEffect2()
{
    for (AElemental* Elem : Elementals)
    {
        if (Elem && Elem->bLightningSkillUnlocked && bIsWeaponEquipped)
        {
            if (Weapon->ActivateEffect(2))
            {
                LightningAura->Activate(true);
            }
            break;
        }
    }
}

void AMyPlayer::FireEffect3()
{
    for (AElemental* Elem : Elementals)
    {
        if (Elem && Elem->bFireSkillUnlocked && bIsWeaponEquipped)
        {
            if (Weapon->ActivateEffect(3))
            {
                FireAura->Activate(true);
            }
            break;
        }
    }
}

void AMyPlayer::AddHealth(float Amount)
{
    HP = FMath::Clamp(HP + Amount, 0.f, MaxHP);
    UE_LOG(LogTemp, Warning, TEXT("[Player] Health Restored: %f / %f"), HP, MaxHP);
}

// -------------------------------
// Parry / Defense
// -------------------------------
void AMyPlayer::ParryActionPressed()
{
    if (!bIsWeaponEquipped || bIsRolling || bIsDead) return;

    bIsParrying = true;

    if (ParryMontage && AnimInstance)
    {
        AnimInstance->Montage_Play(ParryMontage, 1.f);

        // 델리게이트를 지역 변수로 만들어 바인딩
        FOnMontageEnded EndDelegate;
        EndDelegate.BindUObject(this, &AMyPlayer::OnParryMontageEnded);
        AnimInstance->Montage_SetEndDelegate(EndDelegate, ParryMontage);
    }
}

void AMyPlayer::ParryActionReleased()
{
    if (!bIsParrying) return;

    bIsParrying = false;
    bIsInvincible = false;

    if (AnimInstance && ParryMontage)
    {
        // 패링 모션 중이면 즉시 정지
        AnimInstance->Montage_Stop(0.2f, ParryMontage);
    }
}

void AMyPlayer::OnParryMontageEnded(UAnimMontage* Montage, bool bInterrupted)
{
    if (Montage == ParryMontage)
    {
        bIsParrying = false;
        bIsInvincible = false;
    }
}

// -------------------------------
// Damage
// -------------------------------
void AMyPlayer::ApplyDamage_Implementation(float DamageAmount)
{
    if (bIsInvincible || bIsDead)
    {
        UE_LOG(LogTemp, Warning, TEXT("Damage ignored (I-Frame active)"));
        return;
    }

    // 패링 성공 시 처리
    if (bIsParrying)
    {
        FText BossName;
        AActor* NearestBoss = FindNearest(BossName);

        if (NearestBoss)
        {
            FVector MonsterDir = (NearestBoss->GetActorLocation() - GetActorLocation()).GetSafeNormal();
            FVector Forward = GetActorForwardVector();

            float Dot = FVector::DotProduct(Forward, MonsterDir);

            // 캐릭터가 몬스터를 향하고 있으면 패링 성공
            if (Dot > 0.5f)
            {
                // 기존 패링 성공 처리
                if (AnimInstance && ParryMontage)
                {
                    if (!AnimInstance->Montage_IsPlaying(ParryMontage))
                        AnimInstance->Montage_Play(ParryMontage, 1.f);

                    AnimInstance->Montage_JumpToSection(FName("SuccessParry"), ParryMontage);
                }

                bIsParrying = true;
                bIsInvincible = true;

                GetWorldTimerManager().SetTimerForNextTick([this]()
                    {
                        bIsInvincible = false;
                        bIsParrying = false;
                    });

                FVector BackwardDir = -GetActorForwardVector();
                float KnockbackDistance = 100.f;
                AddActorWorldOffset(BackwardDir * KnockbackDistance, true);

                return;
            }
        }
    }

    // 일반 피격 처리
    HP -= DamageAmount;

    if (AnimInstance && DamageMontage)
    {
        if (!AnimInstance->Montage_IsPlaying(DamageMontage))
            AnimInstance->Montage_Play(DamageMontage, 1.f);

        if (HP <= 0)
            AnimInstance->Montage_JumpToSection(FName("Dead"), DamageMontage);
        else
            AnimInstance->Montage_JumpToSection(FName("Default"), DamageMontage);
    }

    if (HP <= 0)
    {
        UE_LOG(LogTemp, Warning, TEXT("Dead!"));
        bIsDead = true;
        StopLockOn();
    }
}

// -------------------------------
// Lock-On
// -------------------------------
void AMyPlayer::ToggleLockOn() 
{ 
    if (bIsLockedOn) StopLockOn(); 
    else StartLockOn(); 
}

void AMyPlayer::StartLockOn()
{
    if (!bIsWeaponEquipped || bIsDead) return;

    FText BossName;
    AActor* Found = FindNearest(BossName);
    CurrentBossName = BossName;
    if (!Found) return;

    LockedOnTarget = Found;
    bIsLockedOn = true;
    bIsLockOnRotating = true;

    // 캐릭터 회전은 입력 기반 이동과 독립
    bUseControllerRotationYaw = false;
    GetCharacterMovement()->bOrientRotationToMovement = false;

    // 카메라만 락온 대상 바라보기
    RotateCharacterAndCameraToTarget();
}

// -------------------------------
// Lock-On 종료
// -------------------------------
void AMyPlayer::StopLockOn()
{
    bIsLockedOn = false;
    LockedOnTarget = nullptr;
    bIsLockOnRotating = false;
    CurrentBossName = FText::GetEmpty();

    bUseControllerRotationYaw = false;
    GetCharacterMovement()->bOrientRotationToMovement = true;
}

// -------------------------------
// 매 틱마다 호출: 캐릭터는 타겟 바라보고, 카메라 회전은 독립
// -------------------------------
void AMyPlayer::UpdateLockOnRotation(float DeltaTime)
{
    if (!bIsLockedOn || !LockedOnTarget) return;

    float Dist = FVector::Dist(LockedOnTarget->GetActorLocation(), GetActorLocation());
    if (Dist > LockOnSearchRadius)
    {
        StopLockOn();
        return;
    }

    // 캐릭터는 항상 몬스터 방향 바라보기
    FVector ToTarget = LockedOnTarget->GetActorLocation() - GetActorLocation();
    ToTarget.Z = 0.f;
    if (!ToTarget.IsNearlyZero())
    {
        FRotator TargetRot = ToTarget.Rotation();
        FRotator NewRot = FMath::RInterpTo(GetActorRotation(), FRotator(0.f, TargetRot.Yaw, 0.f), DeltaTime, 10.f);
        SetActorRotation(NewRot);
    }

    // 카메라는 독립적으로 플레이어 입력으로 회전 가능
}

// -------------------------------
// 카메라만 락온 타겟 바라보기
// -------------------------------
void AMyPlayer::RotateCharacterAndCameraToTarget()
{
    if (!LockedOnTarget) return;

    if (APlayerController* PC = Cast<APlayerController>(GetController()))
    {
        FVector CamLocation = Camera ? Camera->GetComponentLocation() : GetActorLocation() + FVector(0, 0, 50);
        FRotator CamTargetRot = UKismetMathLibrary::FindLookAtRotation(CamLocation, LockedOnTarget->GetActorLocation());
        PC->SetControlRotation(CamTargetRot);
    }
}

// -------------------------------
// FindNearest Monster
// -------------------------------
AActor* AMyPlayer::FindNearest(FText& OutBossName)
{
    AActor* Nearest = nullptr;
    float MinDistance = LockOnSearchRadius;
    OutBossName = FText::GetEmpty();

    for (TActorIterator<AActor> It(GetWorld()); It; ++It)
    {
        AActor* Actor = *It;
        if (Actor->ActorHasTag("Boss_Fire") ||
            Actor->ActorHasTag("Boss_Ice") ||
            Actor->ActorHasTag("Boss_Stone") ||
            Actor->ActorHasTag("Boss_Final"))
        {
            float Dist = FVector::Dist(Actor->GetActorLocation(), GetActorLocation());
            if (Dist < MinDistance)
            {
                MinDistance = Dist;
                Nearest = Actor;

                if (Actor->ActorHasTag("Boss_Fire"))
                    OutBossName = FText::FromString("Fire Boss");
                else if (Actor->ActorHasTag("Boss_Ice"))
                    OutBossName = FText::FromString("Ice Boss");
                else if (Actor->ActorHasTag("Boss_Stone"))
                    OutBossName = FText::FromString("Stone Boss");
                else if (Actor->ActorHasTag("Boss_Final"))
                    OutBossName = FText::FromString("Boss_Final");
            }
        }
    }

    return Nearest;
}

// -------------------------------------------
// Wrapper: just get name for UI
// -------------------------------------------
FText AMyPlayer::GetNearestBossName()
{
    FText BossName;
    AActor* Boss = FindNearest(BossName);
    return Boss ? BossName : FText::GetEmpty();
}

// -------------------------------
// Monster Range Check (Blueprint-friendly)
// -------------------------------
bool AMyPlayer::IsMonsterInRange()
{
    FText DummyName;
    CurrentBossName = GetNearestBossName();
    return FindNearest(DummyName) != nullptr;
}
    
// 월드맵
void AMyPlayer::ToggleMap()
{
    APlayerController* PC = UGameplayStatics::GetPlayerController(this, 0);
    if (!PC) return;

    if (!bIsMapOpen)
    {
        // ------------------------
        // 월드맵 생성
        // ------------------------
        if (MapWidgetClass)
        {
            MapWidget = CreateWidget<UUserWidget>(PC, MapWidgetClass);
            if (MapWidget)
                MapWidget->AddToViewport(1);       // 맵 가장 아래
        }

        // ------------------------
        // Purification UI는 보이되 클릭은 막지 않게 설정
        // ------------------------
        if (PurificationInstance)
        {
            if (!PurificationInstance->IsInViewport())
                PurificationInstance->AddToViewport(2); // 맵 위에 표시

            // ★ 클릭 막지 않도록 설정 (중요)
            PurificationInstance->SetVisibility(ESlateVisibility::SelfHitTestInvisible);
        }

        // ------------------------
        // 다른 UI는 완전 비활성화
        // ------------------------
        if (DialogueWidgetInstance)
            DialogueWidgetInstance->SetVisibility(ESlateVisibility::Collapsed);

        if (HeaterWidgetInstance)
            HeaterWidgetInstance->SetVisibility(ESlateVisibility::Collapsed);

        // ------------------------
        // 입력 모드 변경
        // ------------------------
        FInputModeGameAndUI Mode;
        Mode.SetWidgetToFocus(MapWidget->TakeWidget());
        Mode.SetLockMouseToViewportBehavior(EMouseLockMode::DoNotLock);
        PC->SetInputMode(Mode);
        PC->bShowMouseCursor = true;

        // 퀘스트 상태 해제
        OnQuest = false;
        OnHeaterQuest = false;

        bIsMapOpen = true;
    }
    else
    {
        // ------------------------
        // 월드맵 닫기
        // ------------------------
        if (MapWidget)
        {
            MapWidget->RemoveFromParent();
            MapWidget = nullptr;
        }

        if (PurificationInstance)
        {
            PurificationInstance->SetVisibility(ESlateVisibility::Collapsed);
        }

        // 게임 입력으로 복귀
        PC->SetInputMode(FInputModeGameOnly());
        PC->bShowMouseCursor = false;

        bIsMapOpen = false;
    }
}