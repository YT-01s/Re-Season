#include "WindMill.h"
#include "Components/StaticMeshComponent.h"

// Sets default values
AWindMill::AWindMill()
{
    PrimaryActorTick.bCanEverTick = true;

    Windmill = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Windmill"));
    RootComponent = Windmill;

    Wind = CreateDefaultSubobject<UNiagaraComponent>(TEXT("Wind"));
    Wind->SetupAttachment(Windmill);
    Wind->bAutoActivate = false;

    Dust1 = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Dust1"));
    Dust1->SetupAttachment(Windmill);
    Dust1->SetRelativeLocation(FVector::ZeroVector);
    Dust1->SetRelativeRotation(FRotator::ZeroRotator);
    Dust1->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
    Dust1->SetCollisionObjectType(ECC_WorldDynamic);
    Dust1->SetCollisionResponseToAllChannels(ECR_Block);

    Dust2 = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Dust2"));
    Dust2->SetupAttachment(Windmill);
    Dust2->SetRelativeLocation(FVector::ZeroVector);
    Dust2->SetRelativeRotation(FRotator::ZeroRotator);
    Dust2->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
    Dust2->SetCollisionObjectType(ECC_WorldDynamic);
    Dust2->SetCollisionResponseToAllChannels(ECR_Block);

    Dust3 = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Dust3"));
    Dust3->SetupAttachment(Windmill);
    Dust3->SetRelativeLocation(FVector::ZeroVector);
    Dust3->SetRelativeRotation(FRotator::ZeroRotator);
    Dust3->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
    Dust3->SetCollisionObjectType(ECC_WorldDynamic);
    Dust3->SetCollisionResponseToAllChannels(ECR_Block);

    Handle = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Handle"));
    Handle->SetupAttachment(Windmill);
    Handle->SetRelativeLocation(FVector::ZeroVector);
    Handle->SetRelativeRotation(FRotator::ZeroRotator);
    Handle->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
    Handle->SetCollisionObjectType(ECC_WorldDynamic);
    Handle->SetCollisionResponseToAllChannels(ECR_Block);
}

void AWindMill::BeginPlay()
{
    Super::BeginPlay();

    DustArray = { Dust1, Dust2, Dust3 };
    RemainingDust = DustArray.Num();
}

void AWindMill::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

}

// Katana ��� Dust �浹 �� ȣ��
void AWindMill::RemoveDust()
{
    RemainingDust--;

    if (RemainingDust <= 0)
    {
        HandleRotating = true;
    }
}
