// Fill out your copyright notice in the Description page of Project Settings.


#include "PlayerAnimNotifyState.h"
#include "KatanaBase.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/Actor.h"

void UPlayerAnimNotifyState::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
    if (!MeshComp) return;

    AActor* Owner = MeshComp->GetOwner();
    if (!Owner) return;

    // �÷��̾� ���� Katana ã��
    TArray<AActor*> FoundKatanas;
    UGameplayStatics::GetAllActorsOfClass(Owner->GetWorld(), AKatanaBase::StaticClass(), FoundKatanas);

    for (AActor* Actor : FoundKatanas)
    {
        AKatanaBase* Katana = Cast<AKatanaBase>(Actor);
        if (Katana)
        {
            Katana->StartWeaponTrace();
        }

    }
}

void UPlayerAnimNotifyState::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
    if (!MeshComp) return;

    AActor* Owner = MeshComp->GetOwner();
    if (!Owner) return;

    TArray<AActor*> FoundKatanas;
    UGameplayStatics::GetAllActorsOfClass(Owner->GetWorld(), AKatanaBase::StaticClass(), FoundKatanas);

    for (AActor* Actor : FoundKatanas)
    {
        AKatanaBase* Katana = Cast<AKatanaBase>(Actor);
        if (Katana)
        {
            Katana->StopWeaponTrace();
        }
    }
}