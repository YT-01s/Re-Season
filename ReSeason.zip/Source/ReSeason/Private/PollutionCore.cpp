﻿#include "PollutionCore.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SceneComponent.h"
#include "MyPlayer.h"

// Sets default values
APollutionCore::APollutionCore()
{
	PrimaryActorTick.bCanEverTick = true;

	Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	RootComponent = Root;

	CoreMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("CoreMesh"));
	CoreMesh->SetupAttachment(Root);
	CoreMesh->SetRelativeLocation(FVector::ZeroVector);
	CoreMesh->SetRelativeRotation(FRotator::ZeroRotator);

	NewMaterial = nullptr;
}

void APollutionCore::BeginPlay()
{
	Super::BeginPlay();
}

void APollutionCore::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}

void APollutionCore::OnCoreHit()
{
	// 이미 DestroyCore면 여러번 처리되지 않음
	if (DestroyCore) return;

	// 머티리얼 변경 + DestroyCore = true 설정
	ChangeMaterial(NewMaterial);

	// 이 순간부터 DestroyCore = true 상태가 유지됨
}

/* 머티리얼 변경 함수 */
void APollutionCore::ChangeMaterial(UMaterialInterface* MaterialToApply)
{
	UMaterialInterface* MaterialToUse = MaterialToApply ? MaterialToApply : NewMaterial;

	CoreMesh->SetMaterial(0, MaterialToUse);

	DestroyedCoreEvent();
	AMyPlayer* Player = Cast<AMyPlayer>(GetWorld()->GetFirstPlayerController()->GetPawn());
	if (Player)
	{
		Player->DestroyedCore++;
		UE_LOG(LogTemp, Warning, TEXT(" %d"), Player->DestroyedCore);
	}
	// 개체별 DestroyCore 상태 업데이트
	DestroyCore = true;
}
