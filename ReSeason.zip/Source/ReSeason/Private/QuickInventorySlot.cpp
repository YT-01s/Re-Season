﻿#include "QuickInventorySlot.h"
#include "Components/Image.h"
#include "MyPlayer.h"

void UQuickInventorySlot::NativeConstruct()
{
	Super::NativeConstruct();

	CurrentIndex = 0;
	UpdateSlotImage();
}

void UQuickInventorySlot::ChangeSlotIndex(float ScrollValue)
{
	int32 Direction = 0;

	if (ScrollValue > 0)
	{
		CurrentIndex--;
		Direction = -1;
	}
	else if (ScrollValue < 0)
	{
		CurrentIndex++;
		Direction = +1;
	}

	if (CurrentIndex < 0)
		CurrentIndex = MaxSlots - 1;
	else if (CurrentIndex >= MaxSlots)
		CurrentIndex = 0;

	// 1. 이미지 갱신
	UpdateSlotImage();

	// 2. 방향에 따른 애니메이션 실행
	PlaySlotAnimation(Direction);
}


void UQuickInventorySlot::UpdateSlotImage()
{
	if (SlotIcons.Num() == 0)
		return;

	int32 PrevIndex = (CurrentIndex - 1 + MaxSlots) % MaxSlots;
	int32 NextIndex = (CurrentIndex + 1) % MaxSlots;

	AMyPlayer* Player = Cast<AMyPlayer>(GetOwningPlayerPawn());

	auto UpdateImage = [&](UImage* ImageWidget, int32 Index)
		{
			if (!ImageWidget || !SlotIcons.IsValidIndex(Index))
				return;

			if (Player)
			{
				if (Index == 2) // TreeSeeds 슬롯
				{
					ImageWidget->SetVisibility(Player->TreeSeeds ? ESlateVisibility::Visible : ESlateVisibility::Hidden);
					if (Player->TreeSeeds)
						ImageWidget->SetBrushFromTexture(SlotIcons[Index]);
					return;
				}
				else if (Index == 3) // Brick 슬롯
				{
					ImageWidget->SetVisibility(Player->Brick ? ESlateVisibility::Visible : ESlateVisibility::Hidden);
					if (Player->Brick)
						ImageWidget->SetBrushFromTexture(SlotIcons[Index]);
					return;
				}
			}

			ImageWidget->SetBrushFromTexture(SlotIcons[Index]);
			ImageWidget->SetVisibility(ESlateVisibility::Visible);
		};

	UpdateImage(SlotImage, CurrentIndex);
	UpdateImage(PrevSlotImage, PrevIndex);
	UpdateImage(NextSlotImage, NextIndex);
}

void UQuickInventorySlot::PlaySlotAnimation(int32 Direction)
{
	if (Direction > 0) // 스크롤 ↓ (다음 슬롯)
	{
		if (UpSlot)
		{
			PlayAnimation(UpSlot, 0.f, 1, EUMGSequencePlayMode::Forward, 1.0f);
		}
	}
	else if (Direction < 0) // 스크롤 ↑ (이전 슬롯)
	{
		if (DownSlot)
		{
			PlayAnimation(DownSlot, 0.f, 1, EUMGSequencePlayMode::Forward, 1.0f);
		}
	}
}

void UQuickInventorySlot::UseSelectedItem(AMyPlayer* Player)
{
	if (!Player) return;

	switch (CurrentIndex)
	{
	case 0: // 예: 체력 회복
		Player->ModifyHealth(50.f); // 50 회복
		UE_LOG(LogTemp, Warning, TEXT("Health Restored!"));
		break;

	case 1: // 예: 스테미나 회복
		Player->ModifyStamina(30.f);
		UE_LOG(LogTemp, Warning, TEXT("Stamina Restored!"));
		break;

	case 2:
		Player->PlantTree();
		break;

	case 3:
		Player->TowerReconstruction();
		
		break;

	case 4:
		break;

	default:
		UE_LOG(LogTemp, Warning, TEXT("No item assigned to this slot"));
		break;
	}
}
