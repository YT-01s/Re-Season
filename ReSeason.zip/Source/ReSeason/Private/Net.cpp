﻿#include "Net.h"
#include "Components/BoxComponent.h"
#include "Components/StaticMeshComponent.h"
#include "FloatingTrash.h"
#include "EngineUtils.h"

ANet::ANet()
{
    PrimaryActorTick.bCanEverTick = true;

    Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
    RootComponent = Root;

    FenceBaseR = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("FenceBaseR"));
    FenceBaseR->SetupAttachment(Root);
    FenceBaseR->SetRelativeLocation(FVector::ZeroVector); // Root 기준 위치 0,0,0
    FenceBaseR->SetRelativeRotation(FRotator::ZeroRotator);

    Fence = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("Fence"));
    Fence->SetupAttachment(Root);
    Fence->SetRelativeLocation(FVector::ZeroVector); // Root 기준 위치 0,0,0
    Fence->SetRelativeRotation(FRotator::ZeroRotator);

    FenceBaseL = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("FenceBaseL"));
    FenceBaseL->SetupAttachment(Fence);
    FenceBaseL->SetRelativeLocation(FVector::ZeroVector); // Root 기준 위치 0,0,0
    FenceBaseL->SetRelativeRotation(FRotator::ZeroRotator);

    NetCollision = CreateDefaultSubobject<UBoxComponent>(TEXT("NetCollision"));
    NetCollision->SetupAttachment(Fence);

    NetCollision->SetBoxExtent(FVector(200.f, 200.f, 200.f));
    NetCollision->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
    NetCollision->SetCollisionObjectType(ECC_WorldStatic);
    NetCollision->SetCollisionResponseToAllChannels(ECR_Block);
    NetCollision->SetSimulatePhysics(false); // 고정된 충돌체

    Tags.Add(FName("Net"));
}

void ANet::BeginPlay()
{
    Super::BeginPlay();
    // 초기화 코드 추가 가능

    Fence->SetHiddenInGame(true, true);
    Fence->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    NetCollision->SetCollisionEnabled(ECollisionEnabled::NoCollision);
}

void ANet::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);
    // 매 프레임 처리 코드 추가 가능
}

void ANet::Outspread()
{
    ActiveNet = true;
    Fence->SetHiddenInGame(false, true);
    Fence->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
    NetCollision->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);

    for (TActorIterator<AFloatingTrash> It(GetWorld()); It; ++It)
    {
        AFloatingTrash* Trash = *It;
        if (Trash)
        {
            Trash->ResetTrash();
        }
    }
}