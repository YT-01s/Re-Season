#include "PurificationPercentageWidget.h"
#include "Components/ProgressBar.h"
#include "Components/TextBlock.h"

void UPurificationPercentageWidget::NativeConstruct()
{
	Super::NativeConstruct();

	// ��ȭ ���� ���̺� �ʱ�ȭ
	PurificationScoreTable = {
		{ EPurificationAction::TreePlanting,        0.25f },
		{ EPurificationAction::WindmillActivate,    0.25f },
		{ EPurificationAction::SpringCoreDestroy,   0.25f },
		{ EPurificationAction::Boss_StoneDefeated,  0.25f },

		{ EPurificationAction::NetCasting,          0.25f },
		{ EPurificationAction::PipeActivate,        0.25f },
		{ EPurificationAction::SummerCoreDestroy,   0.25f },
		{ EPurificationAction::Boss_FireDefeated,   0.25f },

		{ EPurificationAction::HeatingControl,      0.25f },
		{ EPurificationAction::TowerRebuildFire,    0.25f },
		{ EPurificationAction::WinterCoreDestroy,   0.25f },
		{ EPurificationAction::Boss_IceDefeated,    0.25f },

		{ EPurificationAction::FinalBossCore,       0.5f },
		{ EPurificationAction::Boss_FinalDefeated,  0.5f }
	};
}

void UPurificationPercentageWidget::UpdatePurification(float NewRatio)
{
	if (PurificationProgressBar)
	{
		// Clamp
		NewRatio = FMath::Clamp(NewRatio, 0.0f, 1.0f);

		// ���� + �� ����
		float CurrentPercent = PurificationProgressBar->GetPercent();
		float NewPercent = FMath::Clamp(CurrentPercent + NewRatio, 0.0f, 1.0f);

		// Bar �ݿ�
		PurificationProgressBar->SetPercent(NewPercent);

		// �ؽ�Ʈ �ݿ�
		if (PercentageText)
		{
			int32 PercentValue = FMath::RoundToInt(NewPercent * 100.0f);
			FString PercentString = FString::Printf(TEXT("%d%%"), PercentValue);
			PercentageText->SetText(FText::FromString(PercentString));
		}
	}
}


void UPurificationPercentageWidget::ApplyPurificationAction(EPurificationAction ActionType)
{
	UE_LOG(LogTemp, Warning, TEXT("ApplyPurificationAction: %d"), (int)ActionType);
	if (!PurificationScoreTable.Contains(ActionType)) {
		UE_LOG(LogTemp, Error, TEXT("PurificationScoreTable does NOT contain this action!"));
		return;
	}

	float AddRatio = PurificationScoreTable[ActionType];

	UpdatePurification(AddRatio);
	UE_LOG(LogTemp, Warning, TEXT("Purification +%.2f Applied"), PurificationScoreTable[ActionType]);
}
