﻿#include "StoneBossAIController.h"
#include "StoneBossCharacter.h"

#include "BehaviorTree/BlackboardComponent.h"
#include "BehaviorTree/BehaviorTree.h"
#include "BehaviorTree/BehaviorTreeComponent.h"

#include "Perception/AIPerceptionComponent.h"
#include "Perception/AISenseConfig_Sight.h"
#include "Kismet/GameplayStatics.h"

const FName AStoneBossAIController::KEY_TargetActor(TEXT("TargetActor"));
const FName AStoneBossAIController::KEY_HasTarget(TEXT("HasTarget"));
const FName AStoneBossAIController::KEY_LastKnownLocation(TEXT("LastKnownLocation"));

AStoneBossAIController::AStoneBossAIController()
{
    // BT/BB
    BehaviorComp = CreateDefaultSubobject<UBehaviorTreeComponent>(TEXT("BehaviorComp"));
    BlackboardComp = CreateDefaultSubobject<UBlackboardComponent>(TEXT("BlackboardComp"));

    // Perception
    PerceptionComp = CreateDefaultSubobject<UAIPerceptionComponent>(TEXT("Perception"));
    SightConfig = CreateDefaultSubobject<UAISenseConfig_Sight>(TEXT("SightConfig"));

    SightConfig->SightRadius = 1500.f;
    SightConfig->LoseSightRadius = 2000.f;
    SightConfig->PeripheralVisionAngleDegrees = 120.f;
    SightConfig->SetMaxAge(5.0f); // 기억 유지 시간
    SightConfig->DetectionByAffiliation.bDetectEnemies = true;
    SightConfig->DetectionByAffiliation.bDetectFriendlies = true;
    SightConfig->DetectionByAffiliation.bDetectNeutrals = true;

    PerceptionComp->ConfigureSense(*SightConfig);
    PerceptionComp->SetDominantSense(SightConfig->GetSenseImplementation());

    PerceptionComp->OnTargetPerceptionUpdated.AddDynamic(this, &AStoneBossAIController::HandlePerceptionUpdated);

    bAttachToPawn = true; // Pawn 교체 시 컴포넌트 attach 유지
}

void AStoneBossAIController::Tick(float DeltaSeconds)
{
    Super::Tick(DeltaSeconds);

    if (!BlackboardComp) return;

    AActor* Target = Cast<AActor>(BlackboardComp->GetValueAsObject(KEY_TargetActor));
    if (!Target) return;

    APawn* BossPawn = GetPawn();
    if (!BossPawn) return;

    float Distance = FVector::Dist(Target->GetActorLocation(), BossPawn->GetActorLocation());

    // 공격 사거리
    const float AttackRange = 250.f;
    // 시야 추적 범위
    const float ChaseRange = 1200.f;

}

void AStoneBossAIController::OnPossess(APawn* InPawn)
{
    Super::OnPossess(InPawn);
    //UE_LOG(LogTemp, Warning, TEXT("[AI] OnPossess Called"));

    if (AStoneBossCharacter* Boss = Cast<AStoneBossCharacter>(InPawn))
    {
        if (Boss->BehaviorTreeAsset)
        {
            //UE_LOG(LogTemp, Warning, TEXT("[AI] RunBehaviorTree: %s"), *Boss->BehaviorTreeAsset->GetName());
            UseBlackboard(Boss->BehaviorTreeAsset->BlackboardAsset, BlackboardComp);
            RunBehaviorTree(Boss->BehaviorTreeAsset);
            // 초기값(안전)
            Blackboard->SetValueAsBool(Boss->GetBBKey_CanCombo(), false);
            Blackboard->SetValueAsInt(Boss->GetBBKey_AttackCount(), 0);
            BehaviorComp->StartTree(*Boss->BehaviorTreeAsset);
        }
        else
        {
            //UE_LOG(LogTemp, Error, TEXT("[AI] Boss has no BehaviorTreeAsset!"));
        }
    }
}


void AStoneBossAIController::OnUnPossess()
{
    Super::OnUnPossess();
    //UE_LOG(LogTemp, Warning, TEXT("OnUnPossess called"));

    if (BehaviorComp && BehaviorComp->IsRunning())
    {
        BehaviorComp->StopTree(EBTStopMode::Safe);
        //UE_LOG(LogTemp, Warning, TEXT("BehaviorTree stopped"));
    }
}

void AStoneBossAIController::HandlePerceptionUpdated(AActor* Actor, FAIStimulus Stimulus)
{
    if (!BlackboardComp) return;

    if (Stimulus.WasSuccessfullySensed())
    {
        //UE_LOG(LogTemp, Warning, TEXT("Perception: Sensed Actor = %s"), *GetNameSafe(Actor));
        BlackboardComp->SetValueAsObject(KEY_TargetActor, Actor);
        BlackboardComp->SetValueAsBool(KEY_HasTarget, true);
        SetFocus(Actor);
    }
    else
    {
        BlackboardComp->SetValueAsBool(KEY_HasTarget, false);
        BlackboardComp->SetValueAsVector(KEY_LastKnownLocation, Stimulus.StimulusLocation);
        ClearFocus(EAIFocusPriority::Gameplay);
    }
}
