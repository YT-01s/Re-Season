﻿#include "FireFieldZone.h"
#include "Components/SphereComponent.h"
#include "NiagaraComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Damageable.h"

AFireFieldZone::AFireFieldZone()
{
    PrimaryActorTick.bCanEverTick = false;

    // 데미지 판정 범위 설정
    DamageArea = CreateDefaultSubobject<USphereComponent>(TEXT("DamageArea"));
    RootComponent = DamageArea;
    DamageArea->InitSphereRadius(300.f);
    DamageArea->SetCollisionProfileName(TEXT("OverlapAllDynamic"));
    DamageArea->SetGenerateOverlapEvents(true);

    // 나이아가라 시각 효과
    FireEffect = CreateDefaultSubobject<UNiagaraComponent>(TEXT("FireEffect"));
    FireEffect->SetupAttachment(RootComponent);
    FireEffect->SetAutoActivate(true);

    // 기본 지속 시간 (Niagara가 루프형일 경우 대비)
    LifeTime = 5.f;
}

void AFireFieldZone::BeginPlay()
{
    Super::BeginPlay();

    // 데미지 영역 이벤트 등록
    DamageArea->OnComponentBeginOverlap.AddDynamic(this, &AFireFieldZone::OnActorEnter);
    DamageArea->OnComponentEndOverlap.AddDynamic(this, &AFireFieldZone::OnActorExit);

    // DOT 타이머 시작
    GetWorldTimerManager().SetTimer(DamageTimerHandle, this, &AFireFieldZone::ApplyDamageToActors, DamageInterval, true);

    // 나이아가라 종료 시점에 맞춰 액터 제거
    if (IsValid(FireEffect))
    {
        // 나이아가라가 끝날 때 호출되는 델리게이트 등록
        FireEffect->OnSystemFinished.AddDynamic(this, &AFireFieldZone::OnNiagaraFinished);

        // 만약 루프형 나이아가라면 OnSystemFinished가 안 불릴 수 있으므로 안전 장치로 수명 지정
        SetLifeSpan(LifeTime);
    }
    else
    {
        // 나이아가라가 없을 경우 대비용
        SetLifeSpan(LifeTime);
    }
}

void AFireFieldZone::OnActorEnter(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
    UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep, const FHitResult& SweepResult)
{
    if (OtherActor && OtherActor != this)
    {
        OverlappingActors.AddUnique(OtherActor);
    }
}

void AFireFieldZone::OnActorExit(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
    UPrimitiveComponent* OtherComp, int32 OtherBodyIndex)
{
    OverlappingActors.Remove(OtherActor);
}

void AFireFieldZone::ApplyDamageToActors()
{
    for (AActor* Target : OverlappingActors)
    {
        if (!IsValid(Target) || Target == this || Target == OwnerActor)
            continue;
        if (IsValid(Target) && Target->Implements<UDamageable>())
        {
            UE_LOG(LogTemp, Warning, TEXT("[FireFieldZone] DOT Damage applied to %s"), *Target->GetName());
            IDamageable::Execute_ApplyDamage(Target, DamagePerTick);
        }
    }
}

// 나이아가라 완전 종료 시점에 자동 호출되는 콜백
void AFireFieldZone::OnNiagaraFinished(UNiagaraComponent* PSystem)
{
    UE_LOG(LogTemp, Warning, TEXT("[FireFieldZone] Niagara system finished → Destroy actor"));
    Destroy();
}
