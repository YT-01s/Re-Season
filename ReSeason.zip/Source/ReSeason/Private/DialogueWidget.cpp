﻿#include "DialogueWidget.h"
#include "Components/TextBlock.h"
#include "Components/Button.h"
#include "MyPlayer.h"

void UDialogueWidget::NativeConstruct()
{
    Super::NativeConstruct();

    if (NextButton)
    {
        NextButton->OnClicked.AddDynamic(this, &UDialogueWidget::OnNextDialogue);
    }
}

void UDialogueWidget::ShowElementalDialogue(const FString& ElementName)
{
    if (!DialogueText)
        return;

    DialogueLines = GetDialogueLinesForElement(ElementName);
    SpeakerName = ElementName;

    if (NameText) NameText->SetText(FText::FromString(Speakers[CurrentIndex]));

    CurrentIndex = 0;

    if (DialogueLines.Num() == 0)
    {
        DialogueText->SetText(FText::FromString(TEXT("...")));
        return;
    }

    // 첫 문장 시작 (타이핑)
    StartTyping(DialogueLines[CurrentIndex]);
}

void UDialogueWidget::OnNextDialogue()
{
    // 타이핑 중이면 = 마무리만 하고 리턴
    if (bIsTyping)
    {
        GetWorld()->GetTimerManager().ClearTimer(TypingTimer);
        bIsTyping = false;

        // 전체 문장 즉시 표시
        DialogueText->SetText(FText::FromString(FullDialogueText));
        TypingIndex = FullDialogueText.Len();
        return;
    }

    // 타이핑이 끝난 상태 → 다음 대사로 이동
    if (DialogueLines.Num() == 0)
        return;

    if (CurrentIndex >= DialogueLines.Num() - 1)
    {
        // 마지막 대사 처리
        DialogueText->SetText(FText::FromString(DialogueLines[CurrentIndex]));

        // Player 관련 처리
        if (APlayerController* PC = GetWorld()->GetFirstPlayerController())
        {
            PC->bShowMouseCursor = false;
            FInputModeGameOnly InputMode;
            PC->SetInputMode(InputMode);

            if (AMyPlayer* Player = Cast<AMyPlayer>(PC->GetPawn()))
            {
                if (SpeakerName == "SpringVillageChief")
                {
                    Player->TreeSeeds = true;
                    Player->QuickInventoryInstance->UpdateSlotImage();
                    Player->CurrentQuest = 1;
                }

                if (SpeakerName == "Wind")
                {
                    Player->CurrentQuest++;
                    if (Player->CurrentQuest == 1)
                    {
                        Player->ClosestElemental->PlayUnlockedMontage();
                    }
                    if (Player->CurrentQuest == 2)
                    {
                        Player->ClosestElemental->PlayUnlockedMontage();
                    }
                    else if (Player->CurrentQuest == 4)
                    {
                        if (Player->DestroyedCore == 3)
                        {
                            Player->CurrentQuest = 10;
                        }
                        else
                        {
                            Player->CurrentQuest = 0;
                        }
                    }
                }

                if (SpeakerName == "SummerDoctor")
                {
                    Player->CurrentQuest = 4;
                }

                if (SpeakerName == "Lightning")
                {
                    Player->CurrentQuest++;
                    if (Player->CurrentQuest == 4)
                    {
                        Player->ClosestElemental->PlayUnlockedMontage();
                    }
                    if (Player->CurrentQuest == 5)
                    {
                        Player->ClosestElemental->PlayUnlockedMontage();
                    }
                    else if (Player->CurrentQuest == 7)
                    {
                        if (Player->DestroyedCore == 3)
                        {
                            Player->CurrentQuest = 10;
                        }
                        else
                        {
                            Player->CurrentQuest = 0;
                        }
                    }
                }

                if (SpeakerName == "WinterBlacksmith")
                {
                    Player->CurrentQuest = 7;
                }

                if (SpeakerName == "Fire")
                {
                    Player->CurrentQuest++;
                    if (Player->CurrentQuest == 7)
                    {
                        Player->ClosestElemental->PlayUnlockedMontage();
                    }
                    if (Player->CurrentQuest == 8)
                    {
                        Player->ClosestElemental->PlayUnlockedMontage();
                    }
                    else if (Player->CurrentQuest == 10)
                    {
                        if (Player->DestroyedCore == 3)
                        {
                            Player->CurrentQuest = 10;
                        }
                        else
                        {
                            Player->CurrentQuest = 0;
                        }
                    }
                }

                Player->OnQuest = false;
                Player->OnHeaterQuest = false;
                Player->SwitchToThirdPerson();
            }
        }

        DialogueLines.Empty();
        CurrentIndex = 0;
        SetVisibility(ESlateVisibility::Hidden);
        return;
    }

    // 다음 대사로 이동
    CurrentIndex++;
    StartTyping(DialogueLines[CurrentIndex]);
    DialogueText->SetText(FText::FromString(DialogueLines[CurrentIndex])); NameText->SetText(FText::FromString(Speakers[CurrentIndex]));
}

void UDialogueWidget::StartTyping(const FString& Text)
{
    if (!DialogueText) return;

    FullDialogueText = Text;
    TypingIndex = 0;
    bIsTyping = true;

    DialogueText->SetText(FText::FromString(TEXT("")));

    GetWorld()->GetTimerManager().SetTimer(
        TypingTimer,
        this,
        &UDialogueWidget::TypeNextCharacter,
        0.03f,
        true
    );
}

void UDialogueWidget::TypeNextCharacter()
{
    if (!DialogueText) return;

    if (TypingIndex >= FullDialogueText.Len())
    {
        GetWorld()->GetTimerManager().ClearTimer(TypingTimer);
        bIsTyping = false;
        return;
    }

    FString CurrentText = FullDialogueText.Left(++TypingIndex);
    DialogueText->SetText(FText::FromString(CurrentText));
}
