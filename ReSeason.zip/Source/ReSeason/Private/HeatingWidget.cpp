﻿#include "HeatingWidget.h"
#include "Components/TextBlock.h"
#include "Components/Slider.h"
#include "Components/Button.h"
#include "MyPlayer.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetMathLibrary.h"

void UHeatingWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
    Super::NativeTick(MyGeometry, InDeltaTime);

    if (APlayerController* PC = GetWorld()->GetFirstPlayerController())
    {
        if (AMyPlayer* Player = Cast<AMyPlayer>(PC->GetPawn()))
        {
            bool bCurrentHeaterController = Player->HeaterController;

            //  false → true 로 바뀌는 순간만 실행
            if (bCurrentHeaterController && !bPrevHeaterController)
            {
                // 30~50 사이의 랜덤 온도 설정
                CurrentTemperature = FMath::FRandRange(30.0f, 70.0f);
                UpdateTemperatureDisplay();

                // 슬라이더들 값도 갱신
                if (TemperatureSlider)
                    TemperatureSlider->SetValue(CurrentTemperature / MaxTemperature);
                if (TemperatureRadialSlider)
                    TemperatureRadialSlider->SetValue(CurrentTemperature / MaxTemperature);

                // 버튼 랜덤 활성화
                ActivateRandomButtons();

                UE_LOG(LogTemp, Warning, TEXT("HeaterController ON → Random Temp: %.1f°C"), CurrentTemperature);
            }
            // true → false 로 바뀌는 순간 버튼 숨김
            else if (!bCurrentHeaterController && bPrevHeaterController)
            {
                HideAllButtons();
                UE_LOG(LogTemp, Warning, TEXT("HeaterController OFF"));
            }

            // 이전 상태 저장
            bPrevHeaterController = bCurrentHeaterController;
        }
    }
}

bool UHeatingWidget::Initialize()
{
    bool Success = Super::Initialize();
    if (!Success) return false;

    if (CloseButton)
        CloseButton->OnClicked.AddDynamic(this, &UHeatingWidget::OnCloseButtonClicked);

    // 기존 직선 슬라이더 설정
    if (TemperatureSlider)
    {
        TemperatureSlider->SetValue(CurrentTemperature / MaxTemperature);
        TemperatureSlider->OnValueChanged.AddDynamic(this, &UHeatingWidget::OnTemperatureSliderChanged);
    }

    // 새로 추가된 원형 슬라이더 설정
    if (TemperatureRadialSlider)
    {
        TemperatureRadialSlider->SetValue(CurrentTemperature / MaxTemperature);
        TemperatureRadialSlider->OnValueChanged.AddDynamic(this, &UHeatingWidget::OnTemperatureRadialChanged);
    }

    if (IncreaseButton)
        IncreaseButton->OnClicked.AddDynamic(this, &UHeatingWidget::OnIncreaseButtonClicked);

    if (DecreaseButton)
        DecreaseButton->OnClicked.AddDynamic(this, &UHeatingWidget::OnDecreaseButtonClicked);

    UpdateTemperatureDisplay();
    return true;
}

void UHeatingWidget::OnTemperatureSliderChanged(float Value)
{
    CurrentTemperature = FMath::Clamp(Value * MaxTemperature, MinTemperature, MaxTemperature);
    UpdateTemperatureDisplay();

    // RadialSlider도 함께 갱신 (양방향 동기화)
    if (TemperatureRadialSlider)
        TemperatureRadialSlider->SetValue(CurrentTemperature / MaxTemperature);
}

void UHeatingWidget::OnTemperatureRadialChanged(float Value)
{
    CurrentTemperature = FMath::Clamp(Value * MaxTemperature, MinTemperature, MaxTemperature);
    UpdateTemperatureDisplay();

    // 직선 슬라이더도 동기화
    if (TemperatureSlider)
        TemperatureSlider->SetValue(CurrentTemperature / MaxTemperature);
}

void UHeatingWidget::OnIncreaseButtonClicked()
{
    CurrentTemperature = FMath::Clamp(CurrentTemperature + TemperatureStep, MinTemperature, MaxTemperature);
    UpdateTemperatureDisplay();

    if (TemperatureSlider)
        TemperatureSlider->SetValue(CurrentTemperature / MaxTemperature);
    if (TemperatureRadialSlider)
        TemperatureRadialSlider->SetValue(CurrentTemperature / MaxTemperature);
}

void UHeatingWidget::OnDecreaseButtonClicked()
{
    CurrentTemperature = FMath::Clamp(CurrentTemperature - TemperatureStep, MinTemperature, MaxTemperature);
    UpdateTemperatureDisplay();

    if (TemperatureSlider)
        TemperatureSlider->SetValue(CurrentTemperature / MaxTemperature);
    if (TemperatureRadialSlider)
        TemperatureRadialSlider->SetValue(CurrentTemperature / MaxTemperature);
}

void UHeatingWidget::ActivateRandomButtons()
{
    int32 RandomIndex = UKismetMathLibrary::RandomIntegerInRange(0, 2);
    if (IncreaseButton && DecreaseButton)
    {
        if (RandomIndex == 0)
        {
            IncreaseButton->SetVisibility(ESlateVisibility::Visible);
            DecreaseButton->SetVisibility(ESlateVisibility::Visible);
        }
        else
        {
            IncreaseButton->SetVisibility(ESlateVisibility::Hidden);
            DecreaseButton->SetVisibility(ESlateVisibility::Hidden);
        }
    }

    if (TemperatureSlider)
    {
        if (RandomIndex == 1)
        {
            TemperatureSlider->SetVisibility(ESlateVisibility::Visible);
        }
        else
        {
            TemperatureSlider->SetVisibility(ESlateVisibility::Hidden);
        }
    }

    if (TemperatureRadialSlider)
    {
        if (RandomIndex == 2)
        {
            TemperatureRadialSlider->SetVisibility(ESlateVisibility::Visible);
        }
        else
        {
            TemperatureRadialSlider->SetVisibility(ESlateVisibility::Hidden);
        }
    }
}

void UHeatingWidget::HideAllButtons()
{
    if (IncreaseButton)
        IncreaseButton->SetVisibility(ESlateVisibility::Hidden);
    if (DecreaseButton)
        DecreaseButton->SetVisibility(ESlateVisibility::Hidden);
    if (TemperatureSlider)
        TemperatureSlider->SetVisibility(ESlateVisibility::Hidden);
    if (TemperatureRadialSlider)
        TemperatureRadialSlider->SetVisibility(ESlateVisibility::Hidden);
}

void UHeatingWidget::UpdateTemperatureDisplay()
{
    if (TemperatureText)
        TemperatureText->SetText(FText::FromString(FString::Printf(TEXT("%.1f°C"), CurrentTemperature)));
}

void UHeatingWidget::OnCloseButtonClicked()
{
    if (APlayerController* PC = GetWorld()->GetFirstPlayerController())
    {
        PC->bShowMouseCursor = false;
        FInputModeGameOnly InputMode;
        PC->SetInputMode(InputMode);

        if (AMyPlayer* Player = Cast<AMyPlayer>(PC->GetPawn()))
        {
            Player->HeaterController = false;
            Player->OnQuest = false;
            Player->OnHeaterQuest = false;

            if (CurrentTemperature >= 18.0f && CurrentTemperature <= 20.0f)
            {
                HeaterCnt++;
                if (HeaterCnt == 3)
                {
                    Player->PurificationInstance->ApplyPurificationAction(EPurificationAction::HeatingControl);
                    Player->ElementalSummoning(200.f);
                }
            }
            SetVisibility(ESlateVisibility::Hidden);
        }
    }

    bPrevHeaterController = false;
}