#include "ANS_RollInvincible.h"
#include "MyPlayer.h"

void UANS_RollInvincible::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
    if (AMyPlayer* Player = Cast<AMyPlayer>(MeshComp->GetOwner()))
    {
        Player->bIsInvincible = true;
        UE_LOG(LogTemp, Warning, TEXT("[Roll I-Frame] Invincible ON"));
    }
}

void UANS_RollInvincible::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
    if (AMyPlayer* Player = Cast<AMyPlayer>(MeshComp->GetOwner()))
    {
        Player->bIsInvincible = false;
        UE_LOG(LogTemp, Warning, TEXT("[Roll I-Frame] Invincible OFF"));
    }
}
