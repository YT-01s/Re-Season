#include "PlantingTrees.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SceneComponent.h"

APlantingTrees::APlantingTrees()
{
    PrimaryActorTick.bCanEverTick = false;

    // Root�� �ܼ� SceneComponent
    Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
    RootComponent = Root;

    // ������ �޽�
    StumpMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("StumpMesh"));
    StumpMesh->SetupAttachment(Root);
    StumpMesh->SetRelativeLocation(FVector::ZeroVector); // Root ���� ��ġ 0,0,0
    StumpMesh->SetRelativeRotation(FRotator::ZeroRotator);

    StumpMesh1 = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("StumpMesh1"));
    StumpMesh1->SetupAttachment(Root);
    StumpMesh1->SetRelativeLocation(FVector::ZeroVector); // Root ���� ��ġ 0,0,0
    StumpMesh1->SetRelativeRotation(FRotator::ZeroRotator);

    // ���� ���� �޽�
    CherryBlossomTreeMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("CherryBlossomTreeMesh"));
    CherryBlossomTreeMesh->SetupAttachment(Root);
    CherryBlossomTreeMesh->SetRelativeLocation(FVector::ZeroVector); // Root ���� ��ġ 0,0,0
    CherryBlossomTreeMesh->SetRelativeRotation(FRotator::ZeroRotator);

    NormalTreeMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("NormalTreeMesh"));
    NormalTreeMesh->SetupAttachment(Root);
    NormalTreeMesh->SetRelativeLocation(FVector::ZeroVector);
    NormalTreeMesh->SetRelativeRotation(FRotator::ZeroRotator);

    bIsPlanted = false;
}

void APlantingTrees::BeginPlay()
{
    Super::BeginPlay();

    int32 RandomIndex = FMath::RandRange(0, 1);

    if (RandomIndex == 0)
    {
        StumpMesh->SetHiddenInGame(false);
        StumpMesh1->SetHiddenInGame(true);
    }
    else
    {
        StumpMesh->SetHiddenInGame(true);
        StumpMesh1->SetHiddenInGame(false);
    }

    CherryBlossomTreeMesh->SetVisibility(false);
    NormalTreeMesh->SetVisibility(false);
}

void APlantingTrees::PlantTree()
{
    if (bIsPlanted) return;
    bIsPlanted = true;

    // �׷��ͱ� �����
    StumpMesh->SetVisibility(false);
    StumpMesh1->SetVisibility(false);
    // �������� ���� ����
    RandomTreeType = FMath::RandRange(0, 1); // 0 �Ǵ� 1

    if (RandomTreeType == 0)
    {
        // ���� ���� Ȱ��ȭ
        CherryBlossomTreeMesh->SetVisibility(true);
    }
    else
    {
        // �Ϲ� ���� Ȱ��ȭ
        NormalTreeMesh->SetVisibility(true);
    }
}