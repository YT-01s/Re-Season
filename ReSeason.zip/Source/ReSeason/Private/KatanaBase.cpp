﻿#include "KatanaBase.h"
#include "Kismet/GameplayStatics.h"
#include "DrawDebugHelpers.h"
#include "Damageable.h"
#include "MyPlayer.h"
#include "Components/AudioComponent.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "WindMill.h"
#include "Tower.h"
#include "Pipeline.h"
#include "PollutionCore.h"

AKatanaBase::AKatanaBase()
{
    PrimaryActorTick.bCanEverTick = true;

    KatanaMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("KatanaMesh"));
    RootComponent = KatanaMesh;

    FireEffect = CreateDefaultSubobject<UNiagaraComponent>(TEXT("KatanaEffect1"));
    FireEffect->SetupAttachment(KatanaMesh);
    FireEffect->bAutoActivate = false;

    LightningEffect = CreateDefaultSubobject<UNiagaraComponent>(TEXT("KatanaEffect2"));
    LightningEffect->SetupAttachment(KatanaMesh);
    LightningEffect->bAutoActivate = false;

    WindEffect = CreateDefaultSubobject<UNiagaraComponent>(TEXT("KatanaEffect3"));
    WindEffect->SetupAttachment(KatanaMesh);
    WindEffect->bAutoActivate = false;
}

void AKatanaBase::BeginPlay()
{
    Super::BeginPlay();
    OwnerPlayer = Cast<AMyPlayer>(GetOwner());

    OriginalWalkSpeed = OwnerPlayer->WalkSpeed;
    OriginalRunSpeed = OwnerPlayer->RunSpeed;
    OriginalAttackDamage = AttackDamage;
    OriginalJump = OwnerPlayer->GetCharacterMovement()->JumpZVelocity;
}

void AKatanaBase::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

    UpdateCooldowns(DeltaTime);

    if (!bWeaponActive) return;

    const FVector CurrentTip = GetWeaponTipLocation();

    if (LastWeaponTip.IsNearlyZero())
    {
        LastWeaponTip = CurrentTip;
        return;
    }

    TArray<FHitResult> Hits;
    FCollisionQueryParams Params(SCENE_QUERY_STAT(KatanaTrace), false);
    Params.AddIgnoredActor(this);

    FCollisionObjectQueryParams ObjParams;
    ObjParams.AddObjectTypesToQuery(ECC_Pawn);
    ObjParams.AddObjectTypesToQuery(ECC_WorldDynamic);

    const FCollisionShape Sphere = FCollisionShape::MakeSphere(WeaponTraceRadius);

    bool bAnyHit = GetWorld()->SweepMultiByObjectType(
        Hits, LastWeaponTip, CurrentTip, FQuat::Identity, ObjParams, Sphere, Params
    );

    if (bAnyHit)
    {
        for (const FHitResult& Hit : Hits)
        {
            AActor* HitActor = Hit.GetActor();
            if (!HitActor || HitActor == this || HitActorsThisSwing.Contains(HitActor)) continue;

            if (HitActor->ActorHasTag("Monster"))
            {
                HitActorsThisSwing.Add(HitActor);
                ApplyHitEffects(HitActor);
            }

            if (HitActor->ActorHasTag("Trash"))
            {
                if (LightningEffect && LightningEffect->IsActive())
                {

                    HitActorsThisSwing.Add(HitActor);
                    ApplyHitEffects(HitActor);

                    EnergyCharge = FMath::Clamp(EnergyCharge + 0.1f, 0.f, MaxEnergyCharge);
                    HitActor->Destroy();
                }
            }

            if (HitActor->ActorHasTag("Core"))
            {

                APollutionCore* Core = Cast<APollutionCore>(HitActor);
                if (!Core || Core->DestroyCore)
                    return;  // 이미 처리된 Core면 중복 충돌 방지

                // 한 번만 충돌 처리됨
                HitActorsThisSwing.Add(HitActor);
                ApplyHitEffects(HitActor);

                Core->OnCoreHit();

                OwnerPlayer->PurificationInstance->ApplyPurificationAction(EPurificationAction::SpringCoreDestroy);
                OwnerPlayer->ElementalSummoning(200.f);
            }

            if (Hit.Component.IsValid() && Hit.Component->ComponentHasTag("FinalCore"))
            {

                APollutionCore* Core = Cast<APollutionCore>(HitActor);
                if (!Core || Core->DestroyCore)
                    return;  // 이미 처리된 Core면 중복 충돌 방지

                // 한 번만 충돌 처리됨
                HitActorsThisSwing.Add(HitActor);
                ApplyHitEffects(HitActor);

                Core->OnCoreHit();

                OwnerPlayer->PurificationInstance->ApplyPurificationAction(EPurificationAction::FinalBossCore);
            }

            if (Hit.Component.IsValid() && Hit.Component->ComponentHasTag("Dust"))
            {

                // 이미 처리한 액터는 제외
                if (!HitActorsThisSwing.Contains(HitActor))
                {
                    HitActorsThisSwing.Add(HitActor);
                    ApplyHitEffects(HitActor);

                    AWindMill* WindMill = Cast<AWindMill>(HitActor);
                    if (WindMill)
                    {
                        WindMill->RemoveDust();
                    }
                    // 충돌한 Dust 컴포넌트만 삭제
                    Hit.Component->DestroyComponent();
                }
            }

            if (Hit.Component.IsValid() && Hit.Component->ComponentHasTag("Handle"))
            {
                if (OwnerPlayer->WindMillQuestClear) return;

                // 이미 처리한 액터는 제외
                if (!HitActorsThisSwing.Contains(HitActor))
                {
                    HitActorsThisSwing.Add(HitActor);
                    ApplyHitEffects(HitActor);

                    AWindMill* WindMill = Cast<AWindMill>(HitActor);

                    if (WindMill && WindMill->HandleRotating && WindEffect && WindEffect->IsActive())
                    {
                        WindMill->SailsRotating = true;
                        WindMill->Wind->Activate(true);
                        OwnerPlayer->WindMillQuestClear = true;
                        OwnerPlayer->PurificationInstance->ApplyPurificationAction(EPurificationAction::WindmillActivate);
                        OwnerPlayer->ElementalSummoning(200.f);
                    }
                    // 충돌한 Dust 컴포넌트만 삭제
                }
            }

            if (Hit.Component.IsValid() && Hit.Component->ComponentHasTag("Valve"))
            {
                if (OwnerPlayer->PipelineQuestClear) return;

                if (ValveSound)
                    UGameplayStatics::PlaySoundAtLocation(GetWorld(), ValveSound, HitActor->GetActorLocation());

                // 중복 처리 방지
                if (!HitActorsThisSwing.Contains(HitActor))
                {
                    HitActorsThisSwing.Add(HitActor);
                    ApplyHitEffects(HitActor);

                    APipeline* Pipeline = Cast<APipeline>(HitActor);

                    if (Pipeline && LightningEffect && LightningEffect->IsActive() && EnergyCharge >= 1.f)
                    {
                        Pipeline->ActivateWater();
                        OwnerPlayer->ClosestElemental->LightningChargeUi = false;
                        OwnerPlayer->PipelineQuestClear = true;
                        OwnerPlayer->PurificationInstance->ApplyPurificationAction(EPurificationAction::PipeActivate);
                        OwnerPlayer->ElementalSummoning(200.f);
                    }
                }
            }

            if (Hit.Component.IsValid() && Hit.Component->ComponentHasTag("Fire"))
            {
                if (OwnerPlayer->TowerQuestClear) return;

                // 중복 처리 방지
                if (!HitActorsThisSwing.Contains(HitActor))
                {
                    HitActorsThisSwing.Add(HitActor);
                    ApplyHitEffects(HitActor);

                    // 만약 부딪힌 액터가 Tower라면
                    ATower* Tower = Cast<ATower>(HitActor);

                    if (Tower && FireEffect && FireEffect->IsActive() && Tower->TowerQuestClear)
                    {
                        Tower->ActivateFire();
                        OwnerPlayer->TowerQuestClear = true;
                        OwnerPlayer->PurificationInstance->ApplyPurificationAction(EPurificationAction::TowerRebuildFire);
                        OwnerPlayer->ElementalSummoning(200.f);
                    }
                }
            }  
        }
    }
    else
    {
        //DrawDebugLine(GetWorld(), LastWeaponTip, CurrentTip, FColor::White, false, 0.05f, 0, 1.5f);
        //DrawDebugSphere(GetWorld(), CurrentTip, 5.f, 8, FColor::Cyan, false, 0.05f);
    }

    LastWeaponTip = CurrentTip;
}

FVector AKatanaBase::GetWeaponTipLocation() const
{
    if (KatanaMesh && KatanaMesh->DoesSocketExist(TEXT("WeaponTip")))
        return KatanaMesh->GetSocketTransform(TEXT("WeaponTip"), RTS_World).GetLocation();

    return GetActorLocation() + GetActorForwardVector() * WeaponLength;
}

void AKatanaBase::StartWeaponTrace()
{
    bWeaponActive = true;
    HitActorsThisSwing.Empty();
    LastWeaponTip = GetWeaponTipLocation();
}

void AKatanaBase::StopWeaponTrace()
{
    bWeaponActive = false;
    LastWeaponTip = FVector::ZeroVector;
    HitActorsThisSwing.Empty();
}

bool AKatanaBase::ActivateEffect(int32 EffectIndex)
{
    // 이미 활성화된 효과가 있거나 쿨다운 중이면 불가
    if ((FireEffect && FireEffect->IsActive()) ||
        (LightningEffect && LightningEffect->IsActive()) ||
        (WindEffect && WindEffect->IsActive()))
    {
        return false;
    }

    UNiagaraComponent* EffectToActivate = nullptr;
    USoundBase* SoundToPlay = nullptr;
    float DurationTime = 0.f;

    switch (EffectIndex)
    {
    case 1: // Wind
        if (bWindOnCooldown) return false;
        EffectToActivate = WindEffect;
        SoundToPlay = WindSound;
        DurationTime = WindDuration;
        break;

    case 2: // Electro
        if (bLightningOnCooldown) return false;
        EffectToActivate = LightningEffect;
        SoundToPlay = LightningSound;
        DurationTime = LightningDuration;
        break;

    case 3: // Fire 
        if (bFireOnCooldown) return false;
        EffectToActivate = FireEffect;
        SoundToPlay = FireSound;
        DurationTime = FireDuration;
        break;

    default:
        return false;
    }

    // 모든 효과 비활성화
    StopAllEffects();

    // 효과와 사운드 재생
    if (EffectToActivate) EffectToActivate->Activate(true);
    if (SoundToPlay) ActiveEffectSound = UGameplayStatics::SpawnSoundAttached(SoundToPlay, KatanaMesh);

    // --- 효과 지속 타이머 ---
    GetWorld()->GetTimerManager().SetTimer(
        EffectDurationHandle,
        [this, EffectIndex]()
        {
            StopAllEffects();

            // 각 효과별 버프 해제
            if (EffectIndex == 1) RemoveWindBuff();
            else if (EffectIndex == 2) RemoveLightningBuff();
            else if (EffectIndex == 3) RemoveFireBuff();

            StartEffectCooldown(EffectIndex);
            UE_LOG(LogTemp, Warning, TEXT("Effect %d duration ended."), EffectIndex);
        },
        DurationTime,
        false
    );

    // --- 각 효과별 버프 적용 ---
    if (EffectIndex == 1 && OwnerPlayer->WindMillQuestClear) ApplyWindBuff();
    else if (EffectIndex == 2 && OwnerPlayer->PipelineQuestClear) ApplyLightningBuff();
    else if (EffectIndex == 3 && OwnerPlayer->TowerQuestClear) ApplyFireBuff();

    return true;
}

void AKatanaBase::ApplyHitEffects(AActor* HitActor)
{
    if (!HitActor) return;

    if (HitActor->GetClass()->ImplementsInterface(UDamageable::StaticClass()))
        IDamageable::Execute_ApplyDamage(HitActor, AttackDamage);
    else
        UGameplayStatics::ApplyDamage(HitActor, AttackDamage, nullptr, this, nullptr);

    if (bFireLifeStealActive && OwnerPlayer)
    {
        OwnerPlayer->AddHealth(10.f);
        UE_LOG(LogTemp, Warning, TEXT("[KatanaFireEffect] Lifesteal: Player healed +10 HP"));
    }

    if (HitSound)
        UGameplayStatics::PlaySoundAtLocation(GetWorld(), HitSound, HitActor->GetActorLocation());

    if (HitNiagaraEffect)
        UNiagaraFunctionLibrary::SpawnSystemAtLocation(GetWorld(), HitNiagaraEffect, HitActor->GetActorLocation(), FRotator::ZeroRotator);
}

// ------------------------------
// 스킬 버프
// ------------------------------
void AKatanaBase::ApplyWindBuff() // 바람 스킬: 이동속도 증가
{
    if (!OwnerPlayer) return;

    OwnerPlayer->WalkSpeed *= 1.2f;
    OwnerPlayer->RunSpeed *= 1.2f;

    OwnerPlayer->GetCharacterMovement()->JumpZVelocity *= 1.5f;

    UE_LOG(LogTemp, Warning, TEXT("[KatanaWindEffect] Player movement speed boosted"));
}

void AKatanaBase::RemoveWindBuff()
{
    if (!OwnerPlayer) return;

    OwnerPlayer->WalkSpeed = OriginalWalkSpeed;
    OwnerPlayer->RunSpeed = OriginalRunSpeed;

    OwnerPlayer->GetCharacterMovement()->JumpZVelocity = OriginalJump;

    UE_LOG(LogTemp, Warning, TEXT("[KatanaWindEffect] Player movement speed reverted"));
}

void AKatanaBase::ApplyLightningBuff() // 번개 스킬: 공격 속도 증가 및 4스택 이후 몬스터 0.5초 기정
{
    if (!OwnerPlayer) return;
    AttackSpeed = 1.3f;

    UE_LOG(LogTemp, Warning, TEXT("[KatanaElectroEffect] Visual effect only, no buff applied"));
}

void AKatanaBase::RemoveLightningBuff() 
{
    AttackSpeed = 1.f;
}

void AKatanaBase::ApplyFireBuff() // 불 스킬: 피흡 및 데미지 증가
{
    if (!OwnerPlayer) return;

    OriginalAttackDamage = AttackDamage;
    AttackDamage *= 1.5f;
    bFireLifeStealActive = true;

    UE_LOG(LogTemp, Warning, TEXT("[KatanaFireEffect] Player attack damage boosted"));
}

void AKatanaBase::RemoveFireBuff()
{
    if (!OwnerPlayer) return;

    AttackDamage = OriginalAttackDamage;
    bFireLifeStealActive = false;

    UE_LOG(LogTemp, Warning, TEXT("[KatanaFireEffect] Player attack damage reverted"));
}
// ------------------------------
// 쿨다운 관련
// ------------------------------
float AKatanaBase::GetEffectCooldown(int32 EffectIndex) const
{
    switch (EffectIndex)
    {
    case 1: return WindCooldown;
    case 2: return LightningCooldown;
    case 3: return FireCooldown;
    default: return 0.f;
    }
}

bool AKatanaBase::IsEffectOnCooldown(int32 EffectIndex) const
{
    switch (EffectIndex)
    {
    case 1: return bWindOnCooldown;
    case 2: return bLightningOnCooldown;
    case 3: return bFireOnCooldown;
    default: return false;
    }
}

float AKatanaBase::GetSkillCooldownRatio(int32 EffectIndex) const
{
    switch (EffectIndex)
    {
    case 1: // Wind
        return WindCooldown > 0.f ? 1.f - WindCooldownRemaining / WindCooldown : 1.f;
    case 2: // Electro
        return LightningCooldown > 0.f ? 1.f - LightningCooldownRemaining / LightningCooldown : 1.f;
    case 3: // Fire
        return FireCooldown > 0.f ? 1.f - FireCooldownRemaining / FireCooldown : 1.f;
    default:
        return 1.f;
    }
}

void AKatanaBase::UpdateCooldowns(float DeltaTime)
{
    if (bFireOnCooldown)
    {
        FireCooldownRemaining = FMath::Max(FireCooldownRemaining - DeltaTime, 0.f);
        if (FireCooldownRemaining <= 0.f)
        {
            bFireOnCooldown = false;
            UE_LOG(LogTemp, Warning, TEXT("Fire cooldown ended"));
        }
    }

    if (bLightningOnCooldown)
    {
        LightningCooldownRemaining = FMath::Max(LightningCooldownRemaining - DeltaTime, 0.f);
        if (LightningCooldownRemaining <= 0.f)
        {
            bLightningOnCooldown = false;
            UE_LOG(LogTemp, Warning, TEXT("Electro cooldown ended"));
        }
    }

    if (bWindOnCooldown)
    {
        WindCooldownRemaining = FMath::Max(WindCooldownRemaining - DeltaTime, 0.f);
        if (WindCooldownRemaining <= 0.f)
        {
            bWindOnCooldown = false;
            UE_LOG(LogTemp, Warning, TEXT("Wind cooldown ended"));
        }
    }
}

void AKatanaBase::StartEffectCooldown(int32 EffectIndex)
{
    float* CooldownRemaining = nullptr;
    bool* CooldownFlag = nullptr;

    switch (EffectIndex)
    {
    case 1: CooldownRemaining = &WindCooldownRemaining; CooldownFlag = &bWindOnCooldown; break;
    case 2: CooldownRemaining = &LightningCooldownRemaining; CooldownFlag = &bLightningOnCooldown; break;
    case 3: CooldownRemaining = &FireCooldownRemaining; CooldownFlag = &bFireOnCooldown; break;
    default: return;
    }

    if (!CooldownRemaining || !CooldownFlag) return;

    *CooldownFlag = true;
    *CooldownRemaining = GetEffectCooldown(EffectIndex);
}

// ------------------------------
// StopAllEffects (DeactivateAllEffects 통합)
// ------------------------------
void AKatanaBase::StopAllEffects()
{
    int32 ActiveEffectIndex = 0;

    if (WindEffect && WindEffect->IsActive()) ActiveEffectIndex = 1;
    else if (LightningEffect && LightningEffect->IsActive()) ActiveEffectIndex = 2;
    else if (FireEffect && FireEffect->IsActive()) ActiveEffectIndex = 3;

    if (FireEffect) FireEffect->Deactivate();
    if (LightningEffect) LightningEffect->Deactivate();
    if (WindEffect) WindEffect->Deactivate();

    if (ActiveEffectSound)
    {
        ActiveEffectSound->Stop();
        ActiveEffectSound = nullptr;
    }

    GetWorld()->GetTimerManager().ClearTimer(EffectDurationHandle);

    RemoveFireBuff();
    RemoveWindBuff();
    RemoveLightningBuff();

    if (ActiveEffectIndex != 0)
    {
        StartEffectCooldown(ActiveEffectIndex);
        UE_LOG(LogTemp, Warning, TEXT("Effect %d interrupted: cooldown started immediately."), ActiveEffectIndex);
    }
}
