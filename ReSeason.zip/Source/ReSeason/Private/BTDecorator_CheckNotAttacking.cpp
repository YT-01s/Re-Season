﻿#include "BTDecorator_CheckNotAttacking.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "AIController.h"
#include "BossCharacter.h"

UBTDecorator_CheckNotAttacking::UBTDecorator_CheckNotAttacking()
{
    NodeName = TEXT("Check Not Attacking");
}

bool UBTDecorator_CheckNotAttacking::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
    AAIController* AICon = OwnerComp.GetAIOwner();
    if (!AICon) return false;

    ABossCharacter* Boss = Cast<ABossCharacter>(AICon->GetPawn());
    if (!Boss) return false;

    AActor* Target = Cast<AActor>(OwnerComp.GetBlackboardComponent()->GetValueAsObject(TEXT("TargetActor")));
    if (!Target) return false;

    const float Dist = FVector::Dist(Boss->GetActorLocation(), Target->GetActorLocation());
    const float Range = Boss->AttackRange; // 보스 클래스에서 가져옴

    UE_LOG(LogTemp, Verbose, TEXT("[BTDecorator_CheckInAttackRange] Dist=%.1f, Range=%.1f"), Dist, Range);

    return Dist <= Range;
}
