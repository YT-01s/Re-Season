﻿#include "MyPlayerAnim.h"
#include "MyPlayer.h"
#include "GameFramework/CharacterMovementComponent.h"

UMyPlayerAnim::UMyPlayerAnim()
{
}

void UMyPlayerAnim::NativeUpdateAnimation(float DeltaSeconds)
{
	Super::NativeUpdateAnimation(DeltaSeconds);

	// --- Pawn 확인 ---
	APawn* Pawn = TryGetPawnOwner();
	if (!IsValid(Pawn)) return;

	AMyPlayer* Player = Cast<AMyPlayer>(Pawn);
	if (!Player) return;

	// --- Movement ---
	CurrentSpeed = Player->GetVelocity().Size();

	if (UCharacterMovementComponent* MoveComp = Player->GetCharacterMovement())
	{
		bIsFalling = MoveComp->IsFalling();
	}

	// --- Weapon ---
	WeaponBlendValue = Player->WeaponBlendValue;
	bIsLockedOn = Player->bIsLockedOn;

	// --- Input Axis ---
	Vertical = Player->ForwardAxisValue;
	Horizontal = Player->RightAxisValue;
}

// --- Notify Functions ---
void UMyPlayerAnim::AnimNotify_EnableNextCombo()
{
	if (AMyPlayer* Player = Cast<AMyPlayer>(TryGetPawnOwner()))
	{
		Player->bCanNextCombo = true;
	}
}

void UMyPlayerAnim::AnimNotify_EquipWeapon()
{
	if (AMyPlayer* Player = Cast<AMyPlayer>(TryGetPawnOwner()))
	{
		Player->EquipWeapon();
	}
}

void UMyPlayerAnim::AnimNotify_UnequipWeapon()
{
	if (AMyPlayer* Player = Cast<AMyPlayer>(TryGetPawnOwner()))
	{
		Player->UnequipWeapon();
	}
}

void UMyPlayerAnim::AnimNotify_PlantTree()
{
	if (AMyPlayer* Player = Cast<AMyPlayer>(TryGetPawnOwner()))
	{
		if (Player->TargetPlantSpot)
		{
			Player->TargetPlantSpot->PlantTree();
			Player->TargetPlantSpot = nullptr;
			Player->OnQuest = false;
			Player->TreeCnt++;

			if (Player->TreeCnt == 3)
			{
				Player->PurificationInstance->ApplyPurificationAction(EPurificationAction::TreePlanting);
				Player->ElementalSummoning(200.f);
			}
		}
	}
}

// AnimNotify_NetCast
void UMyPlayerAnim::AnimNotify_NetCast()
{
	if (AMyPlayer* Player = Cast<AMyPlayer>(TryGetPawnOwner()))
	{
		if (Player->TargetNet)
		{
			Player->TargetNet->Outspread();
			Player->PurificationInstance->ApplyPurificationAction(EPurificationAction::NetCasting);
			Player->OnQuest = false;
			Player->ElementalSummoning(200.f);
		}
	}
}

void UMyPlayerAnim::AnimNotify_PickupBrick()
{
	if (AMyPlayer* Player = Cast<AMyPlayer>(TryGetPawnOwner()))
	{
		if (Player->TargetBrickSpot)
		{
			Player->BrickCount += 1;

			Player->Brick = true;
			Player->OnQuest = false;
			Player->QuickInventoryInstance->UpdateSlotImage();
		}
	}
}

void UMyPlayerAnim::AnimNotify_TowerRepair()
{
	if (AMyPlayer* Player = Cast<AMyPlayer>(TryGetPawnOwner()))
	{
		if (Player->TargetTower)
		{
			Player->BrickCount -= 1;
			Player->TargetTower->AddBrick(1);
			Player->Brick = false;

			Player->OnQuest = false;
			Player->QuickInventoryInstance->UpdateSlotImage();
		}
	}
}