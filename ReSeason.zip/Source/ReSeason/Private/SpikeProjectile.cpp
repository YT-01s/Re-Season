﻿#include "SpikeProjectile.h"
#include "Components/BoxComponent.h"
#include "NiagaraComponent.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "DrawDebugHelpers.h"
#include "Damageable.h"

ASpikeProjectile::ASpikeProjectile()
{
    PrimaryActorTick.bCanEverTick = false;

    Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
    RootComponent = Root;

    // 직선형 콜리전 (가시 장판)
    CollisionBox = CreateDefaultSubobject<UBoxComponent>(TEXT("CollisionBox"));
    CollisionBox->SetupAttachment(Root);
    CollisionBox->SetBoxExtent(FVector(400.f, 100.f, 40.f));
    CollisionBox->SetCollisionEnabled(ECollisionEnabled::NoCollision);
    CollisionBox->SetCollisionObjectType(ECC_WorldDynamic);
    CollisionBox->SetCollisionResponseToAllChannels(ECR_Ignore);
    CollisionBox->SetCollisionResponseToChannel(ECC_Pawn, ECR_Overlap);
    CollisionBox->SetMobility(EComponentMobility::Movable);

    // 나이아가라 이펙트
    NiagaraComp = CreateDefaultSubobject<UNiagaraComponent>(TEXT("NiagaraComp"));
    NiagaraComp->SetupAttachment(Root);
    NiagaraComp->SetAutoActivate(true);
    NiagaraComp->SetMobility(EComponentMobility::Movable);

    LifeTime = 2.5f;        // 장판 유지 시간
    ActivationDelay = 0.2f; // 폭발 전 약간의 지연
}

void ASpikeProjectile::BeginPlay()
{
    Super::BeginPlay();

    // 나이아가라 이펙트 시작
    if (NiagaraComp)
    {
        NiagaraComp->Activate(true);
        UE_LOG(LogTemp, Warning, TEXT("[Spike] Niagara Activated!"));
    }

    // 콜리전 활성화
    CollisionBox->SetGenerateOverlapEvents(true);
    CollisionBox->SetCollisionEnabled(ECollisionEnabled::QueryOnly);

    // 스폰 프레임에 겹침 갱신
    CollisionBox->UpdateOverlaps();

    // 딜레이가 있으면 일정 시간 후 판정 실행
    if (ActivationDelay > 0.f)
    {
        GetWorldTimerManager().SetTimer(Timer_Impact, this, &ASpikeProjectile::DoOneShotDamage, ActivationDelay, false);
    }
    else
    {
        DoOneShotDamage();
    }

    // 자동 제거
    SetLifeSpan(LifeTime);
}

void ASpikeProjectile::DoOneShotDamage()
{
    if (bHasAppliedDamage) return;
    bHasAppliedDamage = true;

    // Overlap 정보 갱신 (스폰 지연 있을 때 필수)
    CollisionBox->UpdateOverlaps();

    TArray<AActor*> Overlapping;
    CollisionBox->GetOverlappingActors(Overlapping, ACharacter::StaticClass());

    for (AActor* A : Overlapping)
    {
        if (!A || A == this || A == GetOwner()) continue;

        ACharacter* Player = Cast<ACharacter>(A);
        if (!Player) continue;

        UCharacterMovementComponent* Move = Player->GetCharacterMovement();
        const bool bInAir = Move && Move->IsFalling();
        const bool bOffGround = Move && !Move->IsMovingOnGround();
        const bool bPressedJump = Player->JumpCurrentCount > 0;

        if (bInAir || bOffGround || bPressedJump)
        {
            UE_LOG(LogTemp, Warning, TEXT("[SpikeProjectile] Player jumped over spike, no damage."));
        }
        else
        {
            if (Player->GetClass()->ImplementsInterface(UDamageable::StaticClass()))
            {
                IDamageable::Execute_ApplyDamage(Player, Damage);
                UE_LOG(LogTemp, Warning, TEXT("[SpikeProjectile] Damage via interface: %f"), Damage);
            }
            else
            {
                UGameplayStatics::ApplyDamage(Player, Damage, nullptr, this, nullptr);
                UE_LOG(LogTemp, Warning, TEXT("[SpikeProjectile] Damage via ApplyDamage()"));
            }
        }
    }

    // 판정 1회 후 비활성화
    CollisionBox->SetGenerateOverlapEvents(false);
    CollisionBox->SetCollisionEnabled(ECollisionEnabled::NoCollision);
}
