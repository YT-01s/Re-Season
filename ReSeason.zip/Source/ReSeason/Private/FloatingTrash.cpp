﻿#include "FloatingTrash.h"
#include "Components/SplineComponent.h"
#include "Kismet/KismetMathLibrary.h"
#include "Net.h" // 그물과 충돌 감지용

AFloatingTrash::AFloatingTrash()
{
    PrimaryActorTick.bCanEverTick = true;

    TrashMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("TrashMesh"));
    RootComponent = TrashMesh;

    TrashMesh->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
    TrashMesh->SetCollisionObjectType(ECC_WorldDynamic);
    TrashMesh->SetCollisionResponseToAllChannels(ECR_Block);
    TrashMesh->SetCollisionResponseToChannel(ECC_WorldDynamic, ECR_Overlap); // 동적 객체끼리 충돌 무시

    InputKey = 0.f;
    bIsBlocked = false;

    Tags.Add(FName("Trash"));
}

void AFloatingTrash::BeginPlay()
{
    Super::BeginPlay();

    if (RiverPath && RiverPath->RiverSpline)
    {
        InputKey = RiverPath->RiverSpline->FindInputKeyClosestToWorldLocation(GetActorLocation());
    }

    bHasBeenReset = false;
}

void AFloatingTrash::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);

    // 이미 그물에 걸렸으면 멈춤
    if (bIsBlocked)
        return;

    if (!RiverPath || !RiverPath->RiverSpline)
        return;

    USplineComponent* Spline = RiverPath->RiverSpline;
    const int32 NumPoints = Spline->GetNumberOfSplinePoints();
    const float LastKey = static_cast<float>(NumPoints - 1);

    // 스플라인을 따라 이동
    float MoveSpeed = FlowStrength * DeltaTime * 0.001f;
    InputKey += MoveSpeed;

    if (InputKey > LastKey)
        InputKey = 0.f;

    FVector NewLocation = Spline->GetLocationAtSplineInputKey(InputKey, ESplineCoordinateSpace::World);
    FVector Tangent = Spline->GetTangentAtSplineInputKey(InputKey, ESplineCoordinateSpace::World);
    FRotator NewRotation = Tangent.Rotation();

    // Sweep으로 충돌 감지
    FHitResult Hit;
    SetActorLocation(NewLocation, true, &Hit);
    SetActorRotation(NewRotation);

    if (Hit.bBlockingHit)
    {
        // 충돌한 액터가 Net 태그를 가졌으면 멈춤
        if (Hit.GetActor() && Hit.GetActor()->ActorHasTag("Net"))
        {
            bIsBlocked = true;
            UE_LOG(LogTemp, Warning, TEXT("Trash blocked by Net!"));
        }
    }
}

void AFloatingTrash::ResetTrash()
{
    if (bHasBeenReset)
        return;

    InputKey = 0.f;
    bIsBlocked = false;

    if (RiverPath && RiverPath->RiverSpline)
    {
        FVector StartLocation = RiverPath->RiverSpline->GetLocationAtSplineInputKey(InputKey, ESplineCoordinateSpace::World);
        SetActorLocation(StartLocation);

        FVector Tangent = RiverPath->RiverSpline->GetTangentAtSplineInputKey(InputKey, ESplineCoordinateSpace::World);
        SetActorRotation(Tangent.Rotation());
    }

    bHasBeenReset = true;
}