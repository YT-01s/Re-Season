﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Tower.h"

// Sets default values
ATower::ATower()
{
 	// Set this actor to call Tick() every frame.  You can turn this off to improve performance if you don't need it.
	PrimaryActorTick.bCanEverTick = true;

	Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	RootComponent = Root;

	Fire = CreateDefaultSubobject<UNiagaraComponent>(TEXT("Fire"));
	Fire->SetupAttachment(RootComponent);
	Fire->bAutoActivate = false; // 시작 시 꺼져있게

	Fire2 = CreateDefaultSubobject<UNiagaraComponent>(TEXT("Fire2"));
	Fire2->SetupAttachment(RootComponent);
	Fire2->bAutoActivate = false; // 시작 시 꺼져있게
}

// Called when the game starts or when spawned
void ATower::BeginPlay()
{
	Super::BeginPlay();
	
}

// Called every frame
void ATower::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void ATower::AddBrick(int32 Amount)
{
	CurrentBricks += Amount;
	UE_LOG(LogTemp, Warning, TEXT("Tower received %d brick(s)! Current: %d"), Amount, CurrentBricks);

	if (CurrentBricks >= 3)
	{
		TowerQuestClear = true;
	}

	OnBrickAdded(CurrentBricks);
}

void ATower::ActivateFire()
{
	if (CurrentBricks >= 3)
	{
		Fire->Activate(true);
		Fire2->Activate(true);
		UE_LOG(LogTemp, Log, TEXT("Tower Fire Activated"));

		ActivatePortalTrigger();
	}
}

