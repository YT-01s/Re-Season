#include "ANS_WeaponCollider.h"
#include "StoneBossCharacter.h"   // ���� ĳ���� ���

void UANS_WeaponCollider::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
    float TotalDuration, const FAnimNotifyEventReference& EventReference)
{
    if (!MeshComp) return;

    AStoneBossCharacter* Boss = Cast<AStoneBossCharacter>(MeshComp->GetOwner());
}

void UANS_WeaponCollider::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation,
    const FAnimNotifyEventReference& EventReference)
{
    if (!MeshComp) return;

    AStoneBossCharacter* Boss = Cast<AStoneBossCharacter>(MeshComp->GetOwner());
}
