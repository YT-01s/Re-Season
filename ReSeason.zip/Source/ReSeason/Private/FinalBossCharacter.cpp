﻿#include "FinalBossCharacter.h"
#include "BossAIController.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Animation/AnimInstance.h"
#include "Kismet/GameplayStatics.h"
#include "AIController.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "NiagaraFunctionLibrary.h"
#include "NiagaraComponent.h"
#include "TimerManager.h"
#include "SpikeProjectile.h"
#include "Components/CapsuleComponent.h"

AFinalBossCharacter::AFinalBossCharacter()
{
    BossType = EBossType::FinalBoss;
    WeaponAttachSocketName = TEXT("StoneEquip");

    // 이동 기본값
    GetCharacterMovement()->bUseControllerDesiredRotation = true;
    GetCharacterMovement()->bOrientRotationToMovement = false;
    GetCharacterMovement()->RotationRate = FRotator(0.f, 400.f, 0.f);

    AttackRange = 250.f;
    MoveSpeed = 250.f;

    bUseControllerRotationYaw = true;
    bIsAttacking = false;
    bUseLeftAttack = false;

    AttackCount = 0;
}

void AFinalBossCharacter::BeginPlay()
{
    Super::BeginPlay();

    GetCharacterMovement()->MaxWalkSpeed = MoveSpeed;
    Player = UGameplayStatics::GetPlayerPawn(GetWorld(), 0);

    UE_LOG(LogTemp, Warning, TEXT("[FinalBoss] Behavior Tree 기반 AI 시작"));
}

void AFinalBossCharacter::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);
}

void AFinalBossCharacter::PlayAttackMontage()
{
    if (!GetMesh()) return;
    UAnimInstance* Anim = GetMesh()->GetAnimInstance();
    if (!Anim) return;

    AttackCount++;

    UAnimMontage* Montage = bUseLeftAttack ? LeftAttackMontage : RightAttackMontage;
    if (!Montage)
    {
        UE_LOG(LogTemp, Error, TEXT("[FinalBoss] Missing attack montage!"));
        return;
    }

    bIsAttacking = true;
    bWeaponActive = true;
    HitActorsThisSwing.Empty();

    // BossAIController 직접 접근
    if (ABossAIController* BossAI = Cast<ABossAIController>(GetController()))
    {
        if (UBlackboardComponent* BB = BossAI->GetBlackboardComp())
        {
            BB->SetValueAsInt(TEXT("bIsAttacking"), 1);
            UE_LOG(LogTemp, Warning, TEXT("[FinalBoss] bIsAttacking set to 1"));
        }

        BossAI->StopMovement();
    }

    // 이동 잠금
    UCharacterMovementComponent* MoveComp = GetCharacterMovement();
    const float PrevSpeed = MoveComp->MaxWalkSpeed;
    MoveComp->MaxWalkSpeed = 0.f;

    Anim->Montage_Play(Montage, 1.0f);
    bUseLeftAttack = !bUseLeftAttack;

    if (AttackCount >= 2)
    {
        AttackCount = 0; // 초기화

        // 일정 시간 뒤 스폰
        GetWorld()->GetTimerManager().SetTimer(
            SpikeDelayHandle,   // FTimerHandle 변수 선언 필요
            this,
            &AFinalBossCharacter::SpawnSpikeEffect,
            1.5f,   // 딜레이 (초)
            false
        );
    }

    // 공격 종료 후 복구
    FOnMontageEnded EndDelegate;
    EndDelegate.BindLambda([this, PrevSpeed](UAnimMontage*, bool)
        {
            bIsAttacking = false;
            bWeaponActive = false;

            UCharacterMovementComponent* Move = GetCharacterMovement();
            Move->MaxWalkSpeed = PrevSpeed;

            if (ABossAIController* BossAI = Cast<ABossAIController>(GetController()))
            {
                if (UBlackboardComponent* BB = BossAI->GetBlackboardComp())
                {
                    BB->SetValueAsInt(TEXT("bIsAttacking"), 0);
                    BB->SetValueAsInt(TEXT("bCanAttack"), 0);
                    UE_LOG(LogTemp, Warning, TEXT("[FinalBoss] Attack End — bIsAttacking=0, bCanAttack=0"));

                    // 2초 후 다시 공격 가능
                    GetWorld()->GetTimerManager().SetTimer(AttackCooldownHandle, [BossAI]()
                        {
                            if (BossAI && BossAI->GetBlackboardComp())
                            {
                                BossAI->GetBlackboardComp()->SetValueAsInt(TEXT("bCanAttack"), 1);
                                UE_LOG(LogTemp, Warning, TEXT("[FinalBoss] Cooldown End — bCanAttack=1"));
                            }
                        }, 2.0f, false);
                }
            }

            UE_LOG(LogTemp, Warning, TEXT("[FinalBoss] Attack Ended."));
        });

    Anim->Montage_SetEndDelegate(EndDelegate, Montage);
}

void AFinalBossCharacter::DealDamage()
{
    if (!bCountedThisSwing)
    {
        IncrementAttackCount();
        bCountedThisSwing = true;
        UE_LOG(LogTemp, Warning, TEXT("[FinalBoss] DealDamage executed"));
    }
}

void AFinalBossCharacter::SpawnSlashEffect()
{
    if (!SlashEffect || !Weapon) return;

    UNiagaraFunctionLibrary::SpawnSystemAttached(
        SlashEffect, Weapon, TEXT("WeaponTip"),
        FVector::ZeroVector, FRotator::ZeroRotator,
        EAttachLocation::SnapToTargetIncludingScale,
        true, true, ENCPoolMethod::AutoRelease
    );

    UE_LOG(LogTemp, Warning, TEXT("[FinalBoss] Slash Trail spawned."));
}

void AFinalBossCharacter::SpawnSpikeEffect()
{
    if (!Player || !SpikeProjectileClass) return;

    FVector BossLoc = GetActorLocation();
    float HalfHeight = GetCapsuleComponent()->GetScaledCapsuleHalfHeight();
    FVector GroundLoc = BossLoc - FVector(0.f, 0.f, HalfHeight - 10.f);

    FVector PlayerLoc = Player->GetActorLocation();
    FVector Dir = (PlayerLoc - GroundLoc).GetSafeNormal();
    FRotator Rot = Dir.Rotation();

    FActorSpawnParameters Params;
    Params.Owner = this;
    Params.Instigator = GetInstigator();

    GetWorld()->SpawnActor<ASpikeProjectile>(SpikeProjectileClass, GroundLoc, Rot, Params);

    UE_LOG(LogTemp, Warning, TEXT("[FinalBoss] Spike line spawned toward player."));
}