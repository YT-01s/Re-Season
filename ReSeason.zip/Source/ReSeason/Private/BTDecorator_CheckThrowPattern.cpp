#include "BTDecorator_CheckThrowPattern.h"
#include "BehaviorTree/BlackboardComponent.h"

UBTDecorator_CheckThrowPattern::UBTDecorator_CheckThrowPattern()
{
    NodeName = TEXT("Check Throw Pattern (Bool True)");
}

bool UBTDecorator_CheckThrowPattern::CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const
{
    const UBlackboardComponent* BB = OwnerComp.GetBlackboardComponent();
    if (!BB) return false;

    const bool bValue = BB->GetValueAsBool(GetSelectedBlackboardKey());
    return bValue; // true�� �� ���
}
