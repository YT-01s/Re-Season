﻿#include "Elemental.h"
#include "Animation/AnimInstance.h"
#include "MyPlayer.h"
#include "Kismet/GameplayStatics.h"
#include "GameFramework/Character.h"

AElemental::AElemental()
{
	PrimaryActorTick.bCanEverTick = true;

	ElementalMesh = CreateDefaultSubobject<USkeletalMeshComponent>(TEXT("ElementalMesh"));
	RootComponent = ElementalMesh;
}

void AElemental::BeginPlay()
{
	Super::BeginPlay();

	bWindSkillUnlocked = false;
	bLightningSkillUnlocked = false;
	bFireSkillUnlocked = false;
}

void AElemental::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

}

void AElemental::PlaySummonMontage()
{
	if (!ElementalMesh || !SummonMontage)
		return;

	UAnimInstance* AnimInstance = ElementalMesh->GetAnimInstance();
	if (AnimInstance)
	{
		if (!AnimInstance->OnMontageEnded.IsAlreadyBound(this, &AElemental::OnMontageEnded))
		{
			AnimInstance->OnMontageEnded.AddDynamic(this, &AElemental::OnMontageEnded);
		}

		AnimInstance->Montage_Play(SummonMontage);
	}
}

void AElemental::PlayUnlockedMontage()
{
	if (!ElementalMesh || !UnlockedMontage)
		return;

	UAnimInstance* AnimInstance = ElementalMesh->GetAnimInstance();
	if (AnimInstance)
	{
		// 중복 등록 방지
		if (!AnimInstance->OnMontageEnded.IsAlreadyBound(this, &AElemental::OnMontageEnded))
		{
			AnimInstance->OnMontageEnded.AddDynamic(this, &AElemental::OnMontageEnded);
		}

		AnimInstance->Montage_Play(UnlockedMontage);
	}
}


void AElemental::OnMontageEnded(UAnimMontage* Montage, bool bInterrupted)
{
	if (Montage == UnlockedMontage && !bInterrupted)
	{
		OnSkillUnlocked();
	}
	else if (Montage == SummonMontage)
	{
		ACharacter* Player = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);
		if (!Player) return;

		AMyPlayer* MyPlayer = Cast<AMyPlayer>(Player);
		if (!MyPlayer) return;

		if (!MyPlayer->DialogueWidgetInstance)
		{
			UE_LOG(LogTemp, Warning, TEXT("DialogueWidgetInstance is null!"));
		}
		MyPlayer->DialogueWidgetInstance->SetVisibility(ESlateVisibility::Visible);
	}
}

void AElemental::OnSkillUnlocked()
{
	ACharacter* Player = UGameplayStatics::GetPlayerCharacter(GetWorld(), 0);
	if (!Player) return;

	AMyPlayer* MyPlayer = Cast<AMyPlayer>(Player);
	if (!MyPlayer) return;

	if (ElementName == "Wind")
	{
		bWindSkillUnlocked = true;
		UE_LOG(LogTemp, Warning, TEXT("Wind Skill Unlocked!"));
		MyPlayer->WindAura->Activate(true);
	}
	else if (ElementName == "Lightning")
	{
		bLightningSkillUnlocked = true;
		UE_LOG(LogTemp, Warning, TEXT("Lightning Skill Unlocked!"));
		MyPlayer->LightningAura->Activate(true);
		LightningChargeUi = true;
	}
	else if (ElementName == "Fire")
	{
		bFireSkillUnlocked = true;
		UE_LOG(LogTemp, Warning, TEXT("Fire Skill Unlocked!"));
		MyPlayer->FireAura->Activate(true);
	}
}
