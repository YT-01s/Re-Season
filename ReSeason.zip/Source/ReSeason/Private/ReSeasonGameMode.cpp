// Copyright Epic Games, Inc. All Rights Reserved.

#include "ReSeasonGameMode.h"
#include "ReSeasonCharacter.h"
#include "UObject/ConstructorHelpers.h"

AReSeasonGameMode::AReSeasonGameMode()
{
	// set default pawn class to our Blueprinted character
	static ConstructorHelpers::FClassFinder<APawn> PlayerPawnBPClass(TEXT("/Game/1Player/BP_MyPlayer.BP_MyPlayer_C"));
	if (PlayerPawnBPClass.Class != NULL)
	{
		DefaultPawnClass = PlayerPawnBPClass.Class;
	}
}
