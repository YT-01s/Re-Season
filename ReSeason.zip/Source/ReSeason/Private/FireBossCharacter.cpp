﻿// FireBossCharacter.cpp
#include "FireBossCharacter.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Animation/AnimInstance.h"
#include "Kismet/GameplayStatics.h"
#include "Engine/World.h"
#include "AIController.h"
#include "Components/DecalComponent.h"
#include "BehaviorTree/BlackboardComponent.h"
#include "FireFieldZone.h"
#include "DrawDebugHelpers.h"

AFireBossCharacter::AFireBossCharacter()
{
    BossType = EBossType::Fire;

    WeaponAttachSocketName = TEXT("StoneEquip"); // 동일 소켓 사용
    GetCharacterMovement()->bUseControllerDesiredRotation = true;   // 컨트롤러 회전 따름
    GetCharacterMovement()->bOrientRotationToMovement = false;      // 이동 방향 회전 끔
    GetCharacterMovement()->RotationRate = FRotator(0.f, 400.f, 0.f); // 회전 속도 충분히 빠르게
}

void AFireBossCharacter::BeginPlay()
{
    Super::BeginPlay();

    if (Weapon)
    {
        Weapon->SetRelativeScale3D(WeaponScale);
        UE_LOG(LogTemp, Warning, TEXT("[FireBoss] Weapon scale applied: %s"), *WeaponScale.ToString());
    }

    if (FireFieldVFX)
    {
        UNiagaraComponent* WarmupNiagara = UNiagaraFunctionLibrary::SpawnSystemAtLocation(
            GetWorld(),
            FireFieldVFX,
            FVector(0, 0, -10000),     // 카메라에서 안 보이는 위치
            FRotator::ZeroRotator,
            FVector(1.f),
            true, true, ENCPoolMethod::AutoRelease
        );

        if (WarmupNiagara)
        {
            WarmupNiagara->SetAutoDestroy(true);
            WarmupNiagara->DeactivateImmediate(); // 즉시 종료 
        }

        UE_LOG(LogTemp, Warning, TEXT("[FireBoss] Niagara Warm-up complete."));
    }
}

void AFireBossCharacter::Tick(float DeltaTime)
{
    Super::Tick(DeltaTime);
}

void AFireBossCharacter::ApplyDamage_Implementation(float DamageAmount)
{
    Super::ApplyDamage_Implementation(DamageAmount);

    float HPPercent = (CurrentHP / MaxHP) * 100.f;

    // 70% 트리거
    if (!bSpawnedAt70 && HPPercent <= 70.f)
    {
        bSpawnedAt70 = true;
        UE_LOG(LogTemp, Warning, TEXT("[FireBoss] 체력 70%% 이하 — 불 장판 발동!"));
        SpawnFireFieldVFX();
    }

    // 30% 트리거
    if (!bSpawnedAt30 && HPPercent <= 30.f)
    {
        bSpawnedAt30 = true;
        UE_LOG(LogTemp, Warning, TEXT("[FireBoss] 체력 30%% 이하 — 불 장판 발동!"));
        SpawnFireFieldVFX();
    }
}

void AFireBossCharacter::PlayAttackMontage()
{
    if (!GetMesh()) return;
    UAnimInstance* Anim = GetMesh()->GetAnimInstance();
    if (!Anim) return;

    // 왼손 / 오른손 교대
    UAnimMontage* Montage = bUseLeftAttack ? LeftAttackMontage : RightAttackMontage;
    if (!Montage)
    {
        UE_LOG(LogTemp, Error, TEXT("[FireBoss] Missing Left/Right attack montage!"));
        return;
    }

    // 공격 시작
    bIsAttacking = true;
    bWeaponActive = true;                // 무기 트레이스 활성화
    HitActorsThisSwing.Empty();
    LastWeaponTip = FVector::ZeroVector;

    if (AAIController* AICon = Cast<AAIController>(GetController()))
    {
        AICon->StopMovement();
        if (UBlackboardComponent* BB = AICon->GetBlackboardComponent())
        {
            BB->SetValueAsBool(TEXT("bIsAttacking"), true);
        }
    }

    // 이동/회전 잠금
    UCharacterMovementComponent* MoveComp = GetCharacterMovement();
    const float PrevSpeed = MoveComp->MaxWalkSpeed;
    MoveComp->MaxWalkSpeed = 0.f;
    MoveComp->bOrientRotationToMovement = false;
    bUseControllerRotationYaw = false;

    // 공격 몽타주 재생
    bCountedThisSwing = false;
    Anim->Montage_Play(Montage, 1.0f);

    UE_LOG(LogTemp, Warning, TEXT("[FireBoss] %s played (Left=%d)"),
        *Montage->GetName(), bUseLeftAttack ? 1 : 0);

    // 다음 공격엔 반대 손 사용
    bUseLeftAttack = !bUseLeftAttack;

    // 공격 종료 처리
    FOnMontageEnded EndDelegate;
    EndDelegate.BindLambda([this, PrevSpeed](UAnimMontage*, bool)
        {
            bIsAttacking = false;
            bWeaponActive = false;

            UCharacterMovementComponent* Move = GetCharacterMovement();
            Move->MaxWalkSpeed = PrevSpeed;
            Move->bOrientRotationToMovement = true;
            bUseControllerRotationYaw = true;

            if (AAIController* AICon = Cast<AAIController>(GetController()))
            {
                if (UBlackboardComponent* BB = AICon->GetBlackboardComponent())
                {
                    BB->SetValueAsBool(TEXT("bIsAttacking"), false);

                    if (AActor* Target = Cast<AActor>(BB->GetValueAsObject(TEXT("TargetActor"))))
                    {
                        GetWorldTimerManager().SetTimerForNextTick([AICon, Target]()
                            {
                                AICon->MoveToActor(Target, 250.0f, true, true, true, nullptr, true);
                            });
                    }
                }
            }

            UE_LOG(LogTemp, Warning, TEXT("[FireBoss] Attack montage ended — state reset."));
        });
    Anim->Montage_SetEndDelegate(EndDelegate, Montage);
}

void AFireBossCharacter::DealDamage()
{
    if (!bCountedThisSwing)
    {
        IncrementAttackCount();
        bCountedThisSwing = true;
        UE_LOG(LogTemp, Warning, TEXT("[FireBoss] DealDamage called"));
    }
}

void AFireBossCharacter::SpawnSlashEffect()
{
    UE_LOG(LogTemp, Warning, TEXT("[StoneBoss] SpawnSlashEffect() CALLED — Class: %s"), *GetClass()->GetName());

    if (!FireSlashTrail || !Weapon) return;

    UNiagaraComponent* Trail = UNiagaraFunctionLibrary::SpawnSystemAttached(
        FireSlashTrail,
        Weapon,
        TEXT("WeaponTip"), // 소켓 이름
        FVector::ZeroVector,
        FRotator::ZeroRotator,
        EAttachLocation::SnapToTargetIncludingScale,
        true,
        true,
        ENCPoolMethod::AutoRelease
    );

    UE_LOG(LogTemp, Warning, TEXT("[StoneBoss] Spawned Stone Trail Slash!"));
}

void AFireBossCharacter::SpawnFireFieldVFX()
{
    if (!FireFieldVFX)
    {
        UE_LOG(LogTemp, Error, TEXT("[FireBoss] FireFieldVFX not assigned!"));
        return;
    }

    FVector BossLocation = GetActorLocation();

    for (int i = 0; i < 5; i++)
    {
        FVector RandOffset(FMath::RandRange(-400.f, 400.f), FMath::RandRange(-400.f, 400.f), 0.f);
        FVector TraceStart = BossLocation + RandOffset + FVector(0, 0, 300);
        FVector TraceEnd = TraceStart - FVector(0, 0, 1000);

        FHitResult Hit;
        FCollisionQueryParams Params;
        Params.AddIgnoredActor(this);
        bool bHit = GetWorld()->LineTraceSingleByChannel(Hit, TraceStart, TraceEnd, ECC_Visibility, Params);

        FVector SpawnLoc = bHit ? Hit.ImpactPoint + FVector(0, 0, 5.f)
            : BossLocation + RandOffset + FVector(0, 0, 5.f);
        FRotator SpawnRot = FRotator(-90.f, 0.f, 0.f); // 바닥을 향하도록 회전

        // 🔴 1️⃣ 경고용 데칼 생성
        UDecalComponent* WarningDecal = UGameplayStatics::SpawnDecalAtLocation(
            GetWorld(),
            FireWarningDecalMaterial,   // 여기에 M_FireWarningDecal 할당
            FVector(100.f, 100.f, 100.f), // 크기 (지름)
            SpawnLoc,
            SpawnRot,
            1.5f                        // 지속시간 (자동 사라짐)
        );

        if (WarningDecal)
        {
            WarningDecal->SetFadeOut(1.3f, 0.2f); // 서서히 사라지게
        }

        // 1.5초 뒤에 실제 불장판 생성
        FTimerHandle FireDelayHandle;
        UWorld* World = GetWorld();
        GetWorldTimerManager().SetTimer(
            FireDelayHandle,
            [this, World, SpawnLoc]()
            {
                // 나이아가 불장판 VFX (시각 효과)
                UNiagaraComponent* FireField = UNiagaraFunctionLibrary::SpawnSystemAtLocation(
                    World,
                    FireFieldVFX,
                    SpawnLoc + FVector(0.f, 0.f, 20.f),
                    FRotator(0.f, FMath::RandRange(0.f, 360.f), 0.f),
                    FVector(1.f),
                    true,
                    true,
                    ENCPoolMethod::None
                );

                // DOT 데미지용 FireFieldZone 액터 스폰 추가
                if (FireFieldZoneClass)
                {
                    AFireFieldZone* Zone = GetWorld()->SpawnActor<AFireFieldZone>(
                        FireFieldZoneClass,
                        SpawnLoc,
                        FRotator::ZeroRotator
                    );

                    if (Zone)
                    {
                        Zone->OwnerActor = this;
                    }
                }

                UE_LOG(LogTemp, Warning, TEXT("[FireBoss] Fire field & DOT zone spawned at %s"), *SpawnLoc.ToString());
            },
            1.5f,
            false
        );
    }
}