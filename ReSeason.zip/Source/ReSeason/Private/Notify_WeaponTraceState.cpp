#include "Notify_WeaponTraceState.h"
#include "StoneBossCharacter.h"
#include "KatanaBase.h"

void UNotify_WeaponTraceState::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration)
{
	if (!MeshComp) return;

	AActor* Owner = MeshComp->GetOwner();
	if (!Owner) return;

	// ����
	if (ABossCharacter* Boss = Cast<ABossCharacter>(Owner))
	{
		Boss->StartWeaponTrace();
		UE_LOG(LogTemp, Warning, TEXT("[Notify] Weapon Trace BEGIN (Boss)"));
	}

	// �÷��̾�
	else if (AKatanaBase* Katana = Cast<AKatanaBase>(Owner))
	{
		Katana->StartWeaponTrace();
		UE_LOG(LogTemp, Warning, TEXT("[Notify] Weapon Trace BEGIN (Player)"));
	}
}

void UNotify_WeaponTraceState::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	if (!MeshComp) return;

	AActor* Owner = MeshComp->GetOwner();
	if (!Owner) return;

	// ����
	if (ABossCharacter* Boss = Cast<ABossCharacter>(Owner))
	{
		Boss->StopWeaponTrace();
		UE_LOG(LogTemp, Warning, TEXT("[Notify] Weapon Trace END (Boss)"));
	}

	// �÷��̾�
	else if (AKatanaBase* Katana = Cast<AKatanaBase>(Owner))
	{
		Katana->StopWeaponTrace();
		UE_LOG(LogTemp, Warning, TEXT("[Notify] Weapon Trace END (Player)"));
	}
}
