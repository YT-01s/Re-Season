﻿#include "HeatingZone.h"

AHeatingZone::AHeatingZone()
{
	PrimaryActorTick.bCanEverTick = true;

	Root = CreateDefaultSubobject<USceneComponent>(TEXT("Root"));
	RootComponent = Root;
}

void AHeatingZone::BeginPlay()
{
	Super::BeginPlay();
}

void AHeatingZone::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
}