﻿#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Components/TextBlock.h"
#include "Components/Slider.h"
#include "Components/Button.h"
#include "Components/RadialSlider.h"
#include "HeatingWidget.generated.h"

class UTextBlock;
class USlider;
class UButton;
class URadialSlider;

UCLASS()
class RESEASON_API UHeatingWidget : public UUserWidget
{
    GENERATED_BODY()

public:
    virtual bool Initialize() override;
    virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

    UPROPERTY(meta = (BindWidget))
    UButton* CloseButton;

    UPROPERTY(meta = (BindWidgetOptional))
    UButton* IncreaseButton;

    UPROPERTY(meta = (BindWidgetOptional))
    UButton* DecreaseButton;

    UPROPERTY(meta = (BindWidgetOptional))
    USlider* TemperatureSlider;   // 기존 직선 슬라이더 (Optional로 변경)

    UPROPERTY(meta = (BindWidgetOptional))
    URadialSlider* TemperatureRadialSlider;

    UPROPERTY(meta = (BindWidget))
    UTextBlock* TemperatureText;

    UPROPERTY(BlueprintReadOnly)
    float CurrentTemperature = 40.f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Heating")
    float TemperatureStep = 1.0f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Heating")
    float MinTemperature = 0.f;

    UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Heating")
    float MaxTemperature = 100.0f;

    UFUNCTION()
    void OnCloseButtonClicked();

    UFUNCTION()
    void OnTemperatureSliderChanged(float Value);

    UFUNCTION()
    void OnTemperatureRadialChanged(float Value);   // 새 이벤트

    UFUNCTION()
    void OnIncreaseButtonClicked();

    UFUNCTION()
    void OnDecreaseButtonClicked();

    void UpdateTemperatureDisplay();

    UFUNCTION()
    void ActivateRandomButtons();

    UFUNCTION()
    void HideAllButtons();

private:
    bool bActivatedOnce = false;
    bool bPrevHeaterController = false;
    int HeaterCnt = 0;

};
