#pragma once

#include "CoreMinimal.h"
#include "Animation/AnimInstance.h"
#include "MyPlayerAnim.generated.h"

UCLASS()
class RESEASON_API UMyPlayerAnim : public UAnimInstance
{
	GENERATED_BODY()

public:
	UMyPlayerAnim();

protected:
	// --- Core ---
	virtual void NativeUpdateAnimation(float DeltaSeconds) override;

	// --- Notifies ---
	UFUNCTION()
	void AnimNotify_EnableNextCombo();

	UFUNCTION()
	void AnimNotify_EquipWeapon();

	UFUNCTION()
	void AnimNotify_UnequipWeapon();

	UFUNCTION()
	void AnimNotify_PlantTree();

	UFUNCTION()
	void AnimNotify_NetCast();

	UFUNCTION()
	void AnimNotify_PickupBrick();

	UFUNCTION()
	void AnimNotify_TowerRepair();

private:
	// --- Movement ---
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Pawn", meta = (AllowPrivateAccess = "true"))
	bool bIsFalling = false;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Pawn", meta = (AllowPrivateAccess = "true"))
	bool bIsLockedOn = false;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Pawn", meta = (AllowPrivateAccess = "true"))
	float CurrentSpeed = 0.f;

	// --- Weapon ---
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Pawn", meta = (AllowPrivateAccess = "true"))
	float WeaponBlendValue = 0.f; // BlendSpace Y�� ��

	// --- Input Axis ---
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Pawn", meta = (AllowPrivateAccess = "true"))
	float Horizontal = 0.f;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Pawn", meta = (AllowPrivateAccess = "true"))
	float Vertical = 0.f;
};
