#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/Decorators/BTDecorator_BlackboardBase.h"
#include "BTDecorator_CheckThrowPattern.generated.h"

/**
 * IceBoss ���� - bShouldUseThrowPattern�� true�� ���� ���
 */
UCLASS()
class RESEASON_API UBTDecorator_CheckThrowPattern : public UBTDecorator_BlackboardBase
{
    GENERATED_BODY()

    public:
    UBTDecorator_CheckThrowPattern();

protected:
    virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;
};
