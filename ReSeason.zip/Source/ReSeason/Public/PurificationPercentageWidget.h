// Copyright

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "PurificationPercentageWidget.generated.h"

class UProgressBar;
class UTextBlock;

// ��ȭ �ൿ ���� Enum
UENUM(BlueprintType)
enum class EPurificationAction : uint8
{
	None UMETA(DisplayName = "None"),

	// ��
	TreePlanting UMETA(DisplayName = "Tree Planting"),
	WindmillActivate UMETA(DisplayName = "Windmill Activate"),
	SpringCoreDestroy UMETA(DisplayName = "Spring Core Destroy"),
	Boss_StoneDefeated UMETA(DisplayName = "Spring Boss Defeated"),

	// ����
	NetCasting UMETA(DisplayName = "Net Casting"),
	PipeActivate UMETA(DisplayName = "Pipeline Activate"),
	SummerCoreDestroy UMETA(DisplayName = "Summer Core Destroy"),
	Boss_FireDefeated UMETA(DisplayName = "Summer Boss Defeated"),

	// �ܿ�
	HeatingControl UMETA(DisplayName = "Heating Control"),
	TowerRebuildFire UMETA(DisplayName = "Tower Rebuild + Fire"),
	WinterCoreDestroy UMETA(DisplayName = "Winter Core Destroy"),
	Boss_IceDefeated UMETA(DisplayName = "Winter Boss Defeated"),

	// ��������
	FinalBossCore UMETA(DisplayName = "Final Boss Core"),
	Boss_FinalDefeated UMETA(DisplayName = "Final Boss Defeated"),
};

UCLASS()
class RESEASON_API UPurificationPercentageWidget : public UUserWidget
{
	GENERATED_BODY()

protected:

	// ���α׷�����
	UPROPERTY(meta = (BindWidget))
	UProgressBar* PurificationProgressBar;

	// % �ؽ�Ʈ
	UPROPERTY(meta = (BindWidgetOptional))
	UTextBlock* PercentageText;

	// �� �ൿ�� ������ ���̺�
	TMap<EPurificationAction, float> PurificationScoreTable;

	virtual void NativeConstruct() override;

public:

	// �ۼ�Ʈ ���� ������Ʈ
	UFUNCTION(BlueprintCallable, Category = "Purification")
	void UpdatePurification(float NewRatio);

	// �ൿ ��� ������Ʈ
	UFUNCTION(BlueprintCallable, Category = "Purification")
	void ApplyPurificationAction(EPurificationAction ActionType);
};
