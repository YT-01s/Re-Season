﻿// FireFieldZone.h
#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Components/SphereComponent.h"
#include "NiagaraComponent.h"
#include "FireFieldZone.generated.h"

UCLASS()
class RESEASON_API AFireFieldZone : public AActor
{
    GENERATED_BODY()

    public:
    AFireFieldZone();

    FORCEINLINE class USphereComponent* GetDamageArea() const { return DamageArea; }

    UPROPERTY()
    AActor* OwnerActor = nullptr;

protected:
    virtual void BeginPlay() override;

    UPROPERTY(VisibleAnywhere)
    class USphereComponent* DamageArea;

    UPROPERTY(VisibleAnywhere)
    UNiagaraComponent* FireEffect;

    UPROPERTY(EditAnywhere, Category = "Damage")
    float DamageInterval = 0.5f;

    UPROPERTY(EditAnywhere, Category = "Damage")
    float DamagePerTick = 10.f;

    UPROPERTY(EditAnywhere, Category = "Damage")
    float LifeTime = 5.f;

    UPROPERTY(EditAnywhere, Category = "VFX")
    float NiagaraDuration = 3.0f;

    FTimerHandle DamageTimerHandle;

    TArray<AActor*> OverlappingActors;

    void ApplyDamageToActors();

    UFUNCTION()
    void OnActorEnter(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
        UPrimitiveComponent* OtherComp, int32 OtherBodyIndex, bool bFromSweep,
        const FHitResult& SweepResult);

    UFUNCTION()
    void OnActorExit(UPrimitiveComponent* OverlappedComp, AActor* OtherActor,
        UPrimitiveComponent* OtherComp, int32 OtherBodyIndex);

    // 나이아가라 종료 콜백
    UFUNCTION()
    void OnNiagaraFinished(UNiagaraComponent* PSystem);
};
