#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "PlantingTrees.generated.h"

class UStaticMeshComponent;

UCLASS()
class RESEASON_API APlantingTrees : public AActor
{
    GENERATED_BODY()

public:
    APlantingTrees();
    void BeginPlay();

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Root")
    USceneComponent* Root;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Mesh")
    UStaticMeshComponent* StumpMesh;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Mesh")
    UStaticMeshComponent* StumpMesh1;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Mesh")
    UStaticMeshComponent* CherryBlossomTreeMesh;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Mesh")
    UStaticMeshComponent* NormalTreeMesh;

    bool bIsPlanted;

    UFUNCTION()
    void PlantTree();

private:
    int32 RandomTreeType;
};