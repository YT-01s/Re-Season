﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "HeatingZone.generated.h"

class UHeatingWidget;
class APlayerController;
class AMyPlayer;

UCLASS()
class RESEASON_API AHeatingZone : public AActor
{
    GENERATED_BODY()
	
public:	
	AHeatingZone();

protected:
	virtual void BeginPlay() override;

public:	
	virtual void Tick(float DeltaTime) override;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	USceneComponent* Root;
};
