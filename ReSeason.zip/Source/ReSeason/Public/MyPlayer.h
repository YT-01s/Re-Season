﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Character.h"
#include "Camera/CameraComponent.h"
#include "GameFramework/SpringArmComponent.h"
#include "Animation/AnimMontage.h"
#include "MyPlayerAnim.h"
#include "KatanaBase.h"
#include "NiagaraComponent.h"
#include "NiagaraSystem.h"
#include "NiagaraFunctionLibrary.h"
#include "Damageable.h"
#include "PlantingTrees.h"
#include "Elemental.h"
#include "HeatingZone.h"
#include "BrickHoldZone.h"
#include "Tower.h"
#include "Net.h"
#include "DialogueWidget.h"
#include "HeatingWidget.h"
#include "QuickInventorySlot.h"
#include "PurificationPercentageWidget.h"
#include "MyPlayer.generated.h"

UCLASS()
class RESEASON_API AMyPlayer : public ACharacter, public IDamageable
{
    GENERATED_BODY()

public:
    AMyPlayer();

    // -------------------------------
    // Stats
    // -------------------------------
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float HP = 100.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float MaxHP = 100.f;

    UFUNCTION(BlueprintCallable, Category = "Stats")
    float GetHPRatio() const { return HP / MaxHP; }

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float Stamina = 100.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float MaxStamina = 100.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Stats")
    float StaminaRecoveryRate = 10.f;

    UFUNCTION(BlueprintCallable, Category = "Stats")
    float GetStaminaRatio() const { return Stamina / MaxStamina; }

    bool bIsExhausted = false;

    // 정화도
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Purification")
    float PurificationPercent = 0.f;

    // IDamageable
    virtual void ApplyDamage_Implementation(float DamageAmount) override;

    // Movement
    UFUNCTION(BlueprintCallable, Category = "Movement")
    float GetCurrentSpeedValue() const { return CurrentSpeedValue; }

    // Invincibility
    UPROPERTY(BlueprintReadOnly, Category = "Combat")
    bool bIsInvincible = false;

    // Weapon
    void ToggleWeapon();
    void EquipWeapon();
    void UnequipWeapon();
    bool bCanNextCombo = false;
    float WeaponBlendValue = 0.f;

    // Lock-On
    UPROPERTY(BlueprintReadOnly, Category = "LockOn")
    bool bIsLockedOn = false;

    float ForwardAxisValue = 0.f;
    float RightAxisValue = 0.f;

    void AddHealth(float Amount);

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Movement")
    float WalkSpeed = 350.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Movement")
    float RunSpeed = 600.f;

    UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
    bool HeaterController = false;
    bool OnQuest = false;
    bool OnHeaterQuest = false;

    UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
    AHeatingZone* ClosestHeatingZone;

    UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
    AElemental* ClosestElemental = nullptr;
    void ElementalSummoning(float ForwardOffset);

    // -------------------------------
    // Effects
    // -------------------------------
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "WindAura")
    UNiagaraComponent* WindAura;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "LightningAura")
    UNiagaraComponent* LightningAura;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "FireAura")
    UNiagaraComponent* FireAura;

    void SwitchToFirstPerson(AActor* TargetActor);
    void SwitchToThirdPerson();

    UPROPERTY(BlueprintReadWrite, Category = "UI")
    UDialogueWidget* DialogueWidgetInstance;

    UPROPERTY(BlueprintReadWrite, Category = "UI")
    UHeatingWidget* HeaterWidgetInstance;

    UPROPERTY(BlueprintReadWrite, Category = "UI")
    UQuickInventorySlot* QuickInventoryInstance;

    UPROPERTY(BlueprintReadWrite, Category = "UI")
    UPurificationPercentageWidget* PurificationInstance;

    UFUNCTION(BlueprintCallable)
    void ModifyHealth(float Amount);

    UFUNCTION(BlueprintCallable)
    void ModifyStamina(float Amount);

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
    int32 CurrentQuest = 0;

    bool TreeSeeds = false;
    bool Brick = false;

    void PlantTree();
    void TowerReconstruction();

    UPROPERTY()
    APlantingTrees* TargetPlantSpot; // 현재 상호작용 대상

    int32 TreeCnt = 0;

    UPROPERTY()
    ANet* TargetNet = nullptr;

    UPROPERTY()
    ABrickHoldZone* TargetBrickSpot = nullptr;

    int32 BrickCount = 0;

    UPROPERTY()
    ATower* TargetTower = nullptr;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
    int32 DestroyedCore = 0;

    UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
    bool PipelineQuestClear = false;

    UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
    bool WindMillQuestClear = false;

    UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
    bool TowerQuestClear = false;

private:
    // 월드맵
    UPROPERTY()
    class UUserWidget* MapWidget;

    UPROPERTY(EditAnywhere, Category = "UI")
    TSubclassOf<UUserWidget> MapWidgetClass;

    bool bIsMapOpen = false;

    void ToggleMap(); // M 키 입력 함수
        
protected:
    // -------------------------------
    // Engine Overrides
    // -------------------------------
    virtual void BeginPlay() override;
    virtual void Tick(float DeltaTime) override;
    virtual void PostInitializeComponents() override;
    virtual void SetupPlayerInputComponent(UInputComponent* PlayerInputComponent) override;

    // -------------------------------
    // Camera
    // -------------------------------
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera")
    USpringArmComponent* SpringArm;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera")
    UCameraComponent* Camera;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Camera")
    UCameraComponent* FirstPersonCamera;

    bool bIsFirstPerson;

    // -------------------------------
    // Movement
    // -------------------------------

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Movement")
    float LookSensitivity = 1.f;

    bool bIsRunning = false;

    UPROPERTY(BlueprintReadOnly, Category = "Animation")
    float CurrentSpeedValue = 0.f;

    // -------------------------------
    // Animation
    // -------------------------------
    UPROPERTY()
    UMyPlayerAnim* AnimInstance;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
    UAnimMontage* RollMontage;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
    UAnimMontage* AttackMontage;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
    UAnimMontage* DrawWeaponMontage;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
    UAnimMontage* SheatheWeaponMontage;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
    UAnimMontage* ParryMontage;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
    UAnimMontage* DamageMontage;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Animation")
    UAnimMontage* QuestMontage;

    // 나무 심기 섹션
    FName PlantSection = FName("Plant");
    // 그물 펼치기 섹션
    FName NetSection = FName("Net");
    // 벽돌
    FName BrickSection = FName("Brick");
    // 타워 수리
    FName TowerSection = FName("Tower");

    bool bIsRolling = false;

    FTimerHandle JumpTimerHandle;
    FTimerHandle ParryWindowHandle;
    FTimerHandle ParryCooldownHandle;

    // -------------------------------
    // Weapon
    // -------------------------------

    UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Weapon")
    AKatanaBase* Weapon = nullptr;

    UPROPERTY(EditDefaultsOnly, Category = "Weapon")
    TSubclassOf<AKatanaBase> KatanaBPClass;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Weapon")
    AActor* WeaponSheath = nullptr;

    UPROPERTY(EditDefaultsOnly, Category = "Weapon")
    TSubclassOf<AActor> WeaponSheathBPClass;


    bool bIsWeaponEquipped = false;

    // -------------------------------
    // Attack / Combo
    // -------------------------------
    int32 CurrentCombo = 0;
    int32 MaxCombo = 3;
    bool bIsAttacking = false;

    void AttackAction();
    void PlayAttackMontage();
    void JumpToNextAttackSection();
    void OnAttackMontageEnded(UAnimMontage* Montage, bool bInterrupted);

    // -------------------------------
    // Rolling
    // -------------------------------
    void Rolling();
    void PlayRollMontage(const FString& SectionName);

    // -------------------------------
    // Input
    // -------------------------------
    void MoveForward(float Value);
    void MoveRight(float Value);
    void Turn(float Value);
    void LookUp(float Value);

    void JumpAction();
    void StartRun();
    void StopRun();
    void UseItem();
    void OnMouseWheelUp();
    void OnMouseWheelDown();

    bool OpenMap = false;

    // -------------------------------
    // Katana Effects
    // -------------------------------
    UFUNCTION(BlueprintCallable, Category = "Effect")
    void WindEffect1();

    UFUNCTION(BlueprintCallable, Category = "Effect")
    void LightningEffect2();

    UFUNCTION(BlueprintCallable, Category = "Effect")
    void FireEffect3();

    // -------------------------------
    // Parry
    // -------------------------------
    void ParryActionPressed();
    void ParryActionReleased();

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Parry")
    bool bIsParrying = false;

    // -------------------------------
    // Lock-On
    // -------------------------------
    UPROPERTY(BlueprintReadOnly, Category = "LockOn")
    AActor* LockedOnTarget = nullptr;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "LockOn")
    float LockOnSearchRadius = 2000.f;

    UPROPERTY(EditAnywhere, Category = "LockOn")
    float LockOnRotateSpeed = 8.f;

    bool bIsLockOnRotating = false;

    void ToggleLockOn();
    void StopLockOn();
    void StartLockOn();
    void RotateCharacterAndCameraToTarget();
    void UpdateLockOnRotation(float DeltaTime);
    AActor* FindNearest(FText& OutBossName);

    // -------------------------------
    // Monster Utility
    // -------------------------------
    UFUNCTION(BlueprintCallable, Category = "Monster")
    bool IsMonsterInRange();

    // 패링 성공 후 무적 상태 타이머
    FTimerHandle TimerHandle_ParryInvincible;

    // 무적 해제 함수
    void OnParryMontageEnded(UAnimMontage* Montage, bool bInterrupted);

    bool bIsDead = false;

    // 현재 가장 가까운 보스 이름 저장용 변수
    UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Boss Info")
    FText CurrentBossName;

    // 보스 탐색 관련 함수
    UFUNCTION(BlueprintCallable, Category = "Boss Info")
    FText GetNearestBossName();

    // 상호작용
    UFUNCTION()
    void Interact();

    // 정화도
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UI")
    TSubclassOf<UPurificationPercentageWidget> PurificationWidgetClass;

    TArray<APlantingTrees*> PlantSpots;
    TArray<AHeatingZone*> HeatSpots;
    TArray<AElemental*> Elementals;

    // 오디오
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "BGM")
    class UAudioComponent* BGM_Audio;

    void Quest();

    UPROPERTY()
    AHeatingZone* TargetHeatSpot; // 클래스 멤버

    void SpawnWeapon();
    void InitializePlantSpots();
    void UpdateMovementSpeed(float DeltaTime);
    void UpdateWeaponBlend(float DeltaTime);
    void UpdateStamina(float DeltaTime);
};
