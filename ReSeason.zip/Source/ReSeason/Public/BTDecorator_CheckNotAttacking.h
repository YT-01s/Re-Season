#pragma once

#include "CoreMinimal.h"
#include "BehaviorTree/Decorators/BTDecorator_BlackboardBase.h"
#include "BTDecorator_CheckNotAttacking.generated.h"

/**
 * ���� ���� �ƴ� ���� ����ǵ��� �ϴ� Decorator
 */
UCLASS()
class RESEASON_API UBTDecorator_CheckNotAttacking : public UBTDecorator_BlackboardBase
{
    GENERATED_BODY()

    public:
    UBTDecorator_CheckNotAttacking();

protected:
    virtual bool CalculateRawConditionValue(UBehaviorTreeComponent& OwnerComp, uint8* NodeMemory) const override;
};
