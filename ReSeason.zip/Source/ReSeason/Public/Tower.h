// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "NiagaraComponent.h"
#include "NiagaraSystem.h"
#include "NiagaraFunctionLibrary.h"
#include "Tower.generated.h"

UCLASS()
class RESEASON_API ATower : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	ATower();

	USceneComponent* Root;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Effect")
	UNiagaraComponent* Fire;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Effect")
	UNiagaraComponent* Fire2;

	UFUNCTION(BlueprintCallable, Category = "Effect")
	void ActivateFire();
	
	UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Brick")
	int32 CurrentBricks = 0;
	
	UFUNCTION(BlueprintCallable, Category = "Tower")
	void AddBrick(int32 Amount);

	UFUNCTION(BlueprintImplementableEvent, Category = "Tower")
	void OnBrickAdded(int32 NewBrickCount);

	UFUNCTION(BlueprintImplementableEvent, Category = "Tower")
	void ActivatePortalTrigger();

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	bool TowerQuestClear = false;

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

};
