﻿#pragma once

#include "CoreMinimal.h"
#include "BossCharacter.h"
#include "Animation/AnimMontage.h"
#include "FinalBossCharacter.generated.h"

UCLASS()
class RESEASON_API AFinalBossCharacter : public ABossCharacter
{
    GENERATED_BODY()

    public:
    AFinalBossCharacter();

    virtual void BeginPlay() override;
    virtual void Tick(float DeltaTime) override;

    // ===== 전투 로직 =====
    virtual void PlayAttackMontage() override;   // BTTask_Attack에서 호출
    virtual void DealDamage() override;          // 공격 판정
    virtual void SpawnSlashEffect() override;    // Niagara 슬래시 이펙트

protected:
    // ===== 공격 관련 =====

    // 왼손 / 오른손 공격 몽타주
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "FinalBoss|Attack")
    UAnimMontage* LeftAttackMontage;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "FinalBoss|Attack")
    UAnimMontage* RightAttackMontage;

    // 공격 시 왼손/오른손 교대용
    bool bUseLeftAttack = false;

    // 슬래시 이펙트 (공격 시 소환)
    UPROPERTY(EditAnywhere, Category = "FinalBoss|VFX")
    UNiagaraSystem* SlashEffect;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Boss|Effect")
    TSubclassOf<class ASpikeProjectile> SpikeProjectileClass;

    // 내부 상태 플래그
    bool bWeaponActive = false;      // 무기 트레이스 활성화 여부
    bool bIsAttacking = false;       // 공격 중인지 여부
    bool bCountedThisSwing = false;  // 공격 카운트 중복 방지

    float MoveSpeed;
    APawn* Player;

    FTimerHandle AttackCooldownHandle;

    // 공격 횟수 누적용
    int32 AttackCount;

    // 가시 장판 이펙트 (Niagara)
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Boss|Effect")
    UNiagaraSystem* SpikeEffect;

    // 가시 장판의 이동 속도
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Boss|Effect")
    float SpikeSpeed = 800.f;
    FTimerHandle SpikeDelayHandle;
    FTimerHandle SpikeDamageHandle;
    // 가시 장판 이펙트 소환 함수
    void SpawnSpikeEffect();
};
