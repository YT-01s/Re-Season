// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "AIController.h"
#include "Perception/AIPerceptionTypes.h"
#include "StoneBossAIController.generated.h"

/**
 *
 */
UCLASS()
class RESEASON_API AStoneBossAIController : public AAIController
{
    GENERATED_BODY()

    public:
    AStoneBossAIController();

    virtual void OnPossess(APawn* InPawn) override;
    virtual void OnUnPossess() override;
    virtual void Tick(float DeltaSeconds) override;


protected:
    // Blackboard / BT
    UPROPERTY(VisibleAnywhere, Category = "AI")
    class UBlackboardComponent* BlackboardComp;

    UPROPERTY(VisibleAnywhere, Category = "AI")
    class UBehaviorTreeComponent* BehaviorComp;

    // Perception
    UPROPERTY(VisibleAnywhere, Category = "AI")
    class UAIPerceptionComponent* PerceptionComp;

    UPROPERTY()
    class UAISenseConfig_Sight* SightConfig;

    UFUNCTION()
    void HandlePerceptionUpdated(AActor* Actor, FAIStimulus Stimulus);

    // BB Ű ���� ���ȭ (��Ÿ ����)
    static const FName KEY_TargetActor;
    static const FName KEY_HasTarget;
    static const FName KEY_LastKnownLocation;
};
