#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Components/SplineComponent.h"
#include "RiverSplinePath.generated.h"

UCLASS()
class RESEASON_API ARiverSplinePath : public AActor
{
    GENERATED_BODY()

public:
    ARiverSplinePath();

    // ���� ��θ� ��Ÿ���� ���ö���
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "River")
    USplineComponent* RiverSpline;
};
