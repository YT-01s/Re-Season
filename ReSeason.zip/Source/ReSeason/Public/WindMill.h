﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "NiagaraComponent.h"
#include "NiagaraSystem.h"
#include "NiagaraFunctionLibrary.h"
#include "WindMill.generated.h"

UCLASS()
class RESEASON_API AWindMill : public AActor
{
    GENERATED_BODY()

public:
    AWindMill();

    virtual void BeginPlay() override;
    virtual void Tick(float DeltaTime) override;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
    UStaticMeshComponent* Windmill;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
    UStaticMeshComponent* Dust1;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
    UStaticMeshComponent* Dust2;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
    UStaticMeshComponent* Dust3;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
    UStaticMeshComponent* Handle;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Wind")
    UNiagaraComponent* Wind;

    UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
    bool SailsRotating = false;

    bool HandleRotating = false;

    // Dust를 배열로 관리
    TArray<UStaticMeshComponent*> DustArray;
    float RemainingDust = 0.f;

    // Dust 제거 처리
    void RemoveDust();

private:

};
