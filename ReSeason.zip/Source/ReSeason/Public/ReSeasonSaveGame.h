#pragma once
#include "CoreMinimal.h"
#include "GameFramework/SaveGame.h"
#include "ReSeasonSaveGame.generated.h"

UCLASS()
class RESEASON_API UReSeasonSaveGame : public USaveGame
{
    GENERATED_BODY()

    public:
    UPROPERTY(BlueprintReadWrite, Category = "Player")
    FVector PlayerLocation;

    UPROPERTY(BlueprintReadWrite, Category = "Player")
    FString LevelName;

    UPROPERTY(BlueprintReadWrite, SaveGame)
    float PurificationPercent;
};
