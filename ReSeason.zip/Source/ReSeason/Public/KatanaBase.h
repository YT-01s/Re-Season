#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Components/SkeletalMeshComponent.h"
#include "NiagaraComponent.h"
#include "NiagaraSystem.h"
#include "NiagaraFunctionLibrary.h"
#include "Sound/SoundBase.h"
#include "Components/AudioComponent.h"
#include "KatanaBase.generated.h"

class AMyPlayer;

UCLASS()
class RESEASON_API AKatanaBase : public AActor
{
	GENERATED_BODY()

public:
	AKatanaBase();

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;

	// �޽�
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Mesh")
	USkeletalMeshComponent* KatanaMesh;

	// ����Ʈ
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Effect")
	UNiagaraComponent* FireEffect;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Effect")
	UNiagaraComponent* LightningEffect;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Effect")
	UNiagaraComponent* WindEffect;

	// ����Ʈ ����
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Effect|Sound")
	USoundBase* FireSound;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Effect|Sound")
	USoundBase* LightningSound;

	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Effect|Sound")
	USoundBase* WindSound;

	UPROPERTY()
	UAudioComponent* ActiveEffectSound = nullptr;

	// ���� ����
	UPROPERTY(EditAnywhere, Category = "Weapon|Trace")
	float WeaponTraceRadius = 20.f;

	UPROPERTY(EditAnywhere, Category = "Weapon|Trace")
	float WeaponLength = 150.f;

	UPROPERTY(EditAnywhere, Category = "Weapon|Damage")
	float AttackDamage = 10.f;

	bool bWeaponActive = false;
	FVector LastWeaponTip = FVector::ZeroVector;
	TSet<AActor*> HitActorsThisSwing;

	UPROPERTY(EditDefaultsOnly, Category = "Sound")
	USoundBase* HitSound;

	UPROPERTY(EditDefaultsOnly, Category = "Sound")
	USoundBase* ValveSound;

	UPROPERTY(EditDefaultsOnly, Category = "Effect")
	UNiagaraSystem* HitNiagaraEffect;

	// ����Ʈ�� ��Ÿ��
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Effect|Cooldown")
	float FireCooldown = 10.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Effect|Cooldown")
	float LightningCooldown = 10.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Effect|Cooldown")
	float WindCooldown = 10.0f;

	// ����Ʈ ���ӽð� 
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Effect|Duration")
	float FireDuration = 10.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Effect|Duration")
	float LightningDuration = 10.0f;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Effect|Duration")
	float WindDuration = 10.0f;

	FTimerHandle EffectDurationHandle;

	bool bFireOnCooldown = false;
	bool bLightningOnCooldown = false;
	bool bWindOnCooldown = false;

	FTimerHandle FireCooldownHandle;
	FTimerHandle LightningCooldownHandle;
	FTimerHandle WindCooldownHandle;

	// �÷��̾� ���� 
	UPROPERTY()
	AMyPlayer* OwnerPlayer = nullptr;

	float OriginalWalkSpeed = 0.f;
	float OriginalRunSpeed = 0.f;
	float OriginalAttackDamage = 0.f;
	float OriginalJump = 0.f;

private:
	bool bFireLifeStealActive = false;

	// ���� �Լ� 
	FVector GetWeaponTipLocation() const;
	void ApplyHitEffects(AActor* HitActor);
	void ApplyWindBuff();
	void RemoveWindBuff();
	void ApplyLightningBuff();
	void RemoveLightningBuff();
	void ApplyFireBuff();
	void RemoveFireBuff();

public:
	// ���� Ʈ���̽� 
	void StartWeaponTrace();
	void StopWeaponTrace();

	// ����Ʈ ����
	UFUNCTION(BlueprintCallable, Category = "Effect")
	bool ActivateEffect(int32 EffectIndex);

	// ����Ʈ ��Ÿ�� Ȯ�ο� (��������Ʈ���� ��� ����)
	UFUNCTION(BlueprintCallable, Category = "Effect|Cooldown")
	bool IsEffectOnCooldown(int32 EffectIndex) const;

	UFUNCTION(BlueprintCallable, Category = "Skill")
	float GetSkillCooldownRatio(int32 SkillIndex) const;

	void UpdateCooldowns(float DeltaTime);

	// ��Ÿ�� ���� ����
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Skill|Cooldown")
	float FireCooldownRemaining = 0.f;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Skill|Cooldown")
	float LightningCooldownRemaining = 0.f;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Skill|Cooldown")
	float WindCooldownRemaining = 0.f;

	float GetEffectCooldown(int32 EffectIndex) const;
	void StartEffectCooldown(int32 EffectIndex);
	void StopAllEffects();

	float AttackSpeed = 1.f; // ���ݼӵ�

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	float EnergyCharge = 0.f;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly)
	float MaxEnergyCharge = 1.f;

	UFUNCTION(BlueprintCallable, Category = "Stats")
	float GetEnergyRatio() const { return EnergyCharge / MaxEnergyCharge; }
};
