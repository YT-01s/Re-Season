#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "Components/Image.h"
#include "QuickInventorySlot.generated.h"

class UTextBlock;

UCLASS()
class RESEASON_API UQuickInventorySlot : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeConstruct() override;

	UPROPERTY(meta = (BindWidget))
	UTextBlock* ClickButton; // ��� ǥ�ÿ� �ؽ�Ʈ ����

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory")
	int32 CurrentIndex = 0;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory")
	int32 MaxSlots = 5;

	// ���� �̹��� ���ε�
	UPROPERTY(meta = (BindWidget))
	UImage* PrevSlotImage;

	UPROPERTY(meta = (BindWidget))
	UImage* SlotImage; // ���� ����

	UPROPERTY(meta = (BindWidget))
	UImage* NextSlotImage;

	// ������ �ؽ�ó �迭
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Inventory")
	TArray<UTexture2D*> SlotIcons;

	// �ε��� ���� �Լ�
	UFUNCTION(BlueprintCallable)
	void ChangeSlotIndex(float ScrollValue);

	UFUNCTION(BlueprintCallable)
	void UseSelectedItem(class AMyPlayer* Player);

	void UpdateSlotImage();
	void PlaySlotAnimation(int32 Direction);

	UPROPERTY(meta = (BindWidgetAnim), Transient)
	UWidgetAnimation* UpSlot;

	UPROPERTY(meta = (BindWidgetAnim), Transient)
	UWidgetAnimation* DownSlot;

protected:

};
