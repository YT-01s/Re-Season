﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "SpikeProjectile.generated.h"

UCLASS()
class RESEASON_API ASpikeProjectile : public AActor
{
    GENERATED_BODY()

    public:
    ASpikeProjectile();

protected:
    virtual void BeginPlay() override;

    UPROPERTY(VisibleAnywhere)
    class USceneComponent* Root;

    UPROPERTY(VisibleAnywhere)
    class UBoxComponent* CollisionBox;

    UPROPERTY(VisibleAnywhere)
    class UNiagaraComponent* NiagaraComp;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Damage")
    float Damage = 20.f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Lifetime")
    float LifeTime = 2.5f;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Delay")
    float ActivationDelay = 0.2f;

    FTimerHandle Timer_Impact;
    bool bHasAppliedDamage = false;


    UFUNCTION()
    void DoOneShotDamage();
};
