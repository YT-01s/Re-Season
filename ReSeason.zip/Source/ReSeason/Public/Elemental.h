﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Elemental.generated.h"

UCLASS()
class RESEASON_API AElemental : public AActor
{
    GENERATED_BODY()

public:
    AElemental();

protected:
    virtual void BeginPlay() override;

public:
    virtual void Tick(float DeltaTime) override;

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
    USkeletalMeshComponent* ElementalMesh;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Element")
    FName ElementName;

    UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Elemental")
    bool bWindSkillUnlocked;

    UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Elemental")
    bool bFireSkillUnlocked;

    UPROPERTY(VisibleAnywhere, BlueprintReadWrite, Category = "Elemental")
    bool bLightningSkillUnlocked;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Elemental")
    UAnimMontage* SummonMontage;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Elemental")
    UAnimMontage* UnlockedMontage;

    UFUNCTION()
    void OnMontageEnded(UAnimMontage* Montage, bool bInterrupted);

    void OnSkillUnlocked();
    void PlayUnlockedMontage();
    void PlaySummonMontage();

    UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
    bool LightningChargeUi = false;

};
