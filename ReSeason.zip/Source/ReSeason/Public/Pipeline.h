// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "NiagaraComponent.h"
#include "NiagaraSystem.h"
#include "NiagaraFunctionLibrary.h"
#include "Pipeline.generated.h"

UCLASS()
class RESEASON_API APipeline : public AActor
{
	GENERATED_BODY()
	
public:	
	// Sets default values for this actor's properties
	APipeline();

	UPROPERTY(VisibleAnywhere)
	USceneComponent* Root;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Water")
	UNiagaraComponent* Water;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Lightning")
	UNiagaraComponent* Lightning;

	UFUNCTION(BlueprintImplementableEvent, Category = "Tower")
	void OnTurnValve();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:	
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	void ActivateWater();

	UPROPERTY(VisibleAnywhere, BlueprintReadWrite)
	bool PipelineQuestClear = false;
};
