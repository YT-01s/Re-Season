﻿#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "Components/StaticMeshComponent.h"
#include "RiverSplinePath.h"
#include "FloatingTrash.generated.h"

UCLASS()
class RESEASON_API AFloatingTrash : public AActor
{
    GENERATED_BODY()

public:
    AFloatingTrash();

protected:
    virtual void BeginPlay() override;

public:
    virtual void Tick(float DeltaTime) override;

    // 강 스플라인 참조
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "River")
    ARiverSplinePath* RiverPath;

    // 메시
    UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Trash")
    UStaticMeshComponent* TrashMesh;

    // 강물 흐름 세기
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Flow")
    float FlowStrength = 150.f;

    void ResetTrash();

private:
    float InputKey;
    bool bIsBlocked; // 그물에 막혔는지 상태 저장
    bool bHasBeenReset;
};
