// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "NiagaraComponent.h"
#include "NiagaraSystem.h"
#include "NiagaraFunctionLibrary.h"
#include "PollutionCore.generated.h"

UCLASS()
class RESEASON_API APollutionCore : public AActor
{
	GENERATED_BODY()

public:
	// Sets default values for this actor's properties
	APollutionCore();

protected:
	// Called when the game starts or when spawned
	virtual void BeginPlay() override;

public:
	// Called every frame
	virtual void Tick(float DeltaTime) override;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Root")
	USceneComponent* Root;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Mesh")
	UStaticMeshComponent* CoreMesh;

	// ������ ��Ƽ����(��������Ʈ���� ���� ����)
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Material")
	UMaterialInterface* NewMaterial;

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Effect")
	UNiagaraComponent* Effect;

	// ��Ƽ���� ���� �Լ�
	UFUNCTION(BlueprintCallable, Category = "Material")
	void ChangeMaterial(UMaterialInterface* MaterialToApply = nullptr);

	void OnCoreHit();

	UPROPERTY(VisibleAnywhere, BlueprintReadOnly)
	bool DestroyCore = false;

	UFUNCTION(BlueprintImplementableEvent)
	void DestroyedCoreEvent();
};
