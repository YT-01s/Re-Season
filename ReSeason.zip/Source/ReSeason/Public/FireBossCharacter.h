﻿#pragma once

#include "CoreMinimal.h"
#include "BossCharacter.h"
#include "Animation/AnimMontage.h"
#include "FireBossCharacter.generated.h"


UCLASS()
class RESEASON_API AFireBossCharacter : public ABossCharacter
{
    GENERATED_BODY()

    public:
    AFireBossCharacter();

    virtual void BeginPlay() override;
    virtual void Tick(float DeltaTime) override;

    // 기본 전투 로직
    virtual void PlayAttackMontage() override;
    virtual void DealDamage() override;
    virtual void ApplyDamage_Implementation(float DamageAmount) override;

protected:
    // 양손 공격 몽타주
    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fire|Attack")
    UAnimMontage* LeftAttackMontage;

    UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Fire|Attack")
    UAnimMontage* RightAttackMontage;

    // 공격 시 왼손/오른손 교대용
    bool bUseLeftAttack = true;

    virtual void SpawnSlashEffect() override;
    // 이펙트
    UPROPERTY(EditAnywhere, Category = "VFX")
    UNiagaraSystem* FireSlashTrail;

    // 불 장판 VFX
    UPROPERTY(EditAnywhere, Category = "Fire|Skill")
    UNiagaraSystem* FireFieldVFX;

    // 미리보기 장판
    UPROPERTY(EditAnywhere, Category = "Fire|Skill")
    UMaterialInterface* FireWarningDecalMaterial;

    // 장판 클래스
    UPROPERTY(EditAnywhere, Category = "Fire|Skill")
    TSubclassOf<class AFireFieldZone> FireFieldZoneClass;


    // 불 장판 체력 트리거 플래그
    bool bSpawnedAt70 = false;
    bool bSpawnedAt30 = false;

    // 불 장판 스폰 함수
    void SpawnFireFieldVFX();
};
